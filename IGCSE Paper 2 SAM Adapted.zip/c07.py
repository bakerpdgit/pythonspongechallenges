# IGCSE CS SAMPLE ASSESSMENT REWRITTEN FOR EDEXCEL CS STYLE

# ---------------------------------
# Global variables
# ---------------------------------
myNumbers = []
t = 0
theNumber = 0

# ---------------------------------
# Main program
# ---------------------------------
myNumbers = [20, 25, 30, 40, 47, 50]

for theNumber in myNumbers:
  if(theNumber % 2 == 0):
    t = t + theNumber
    print("Adding even number", theNumber)
  else:
    print("Odd found...ignoring")

print("Total of evens:", t)

# ---------------------------------
# =====> Write your answers here in the right hand column
# Left Column                                                      # Right Column
# ---------------------------------
# Give the name of a data structure in the code                    # myNumbers (which is an array)
# Give the line number(s) showing repetition                       # 15 // 15-20
# Give the line number(s) showing selection                        # 16 // 16-20
# Give the name of a variable                                      # total // theNumber // Allow myNumbers 
# Identify a technique that could be added for more readable code: # meaning variable names // more whitespace