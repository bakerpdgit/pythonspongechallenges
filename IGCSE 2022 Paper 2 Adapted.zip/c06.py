# IGCSE CS 2022 REWRITTEN FOR EDEXCEL CS STYLE

#--------------------------------------------
# Library imports
# -------------------------------------------
import random

# -------------------------------------------
# Global variables
# -------------------------------------------

# Array of words
words = ["antelope","ape","badger","bear","beaver","bison","crocodile","elephant",
         "elk","ferret","goat","goose","kangaroo","llama","lion","monkey","moose",
         "orangutan","shark","snake","tiger","whale","wombat"]

#  ==> Add code to initialise variables


# -------------------------------------------
# Sub-Programs
# -------------------------------------------

def generateWord(pWords):
  # Fully completed function that generates and returns a secret word
  randomNum = random.randint(0,len(pWords)-1)
  secretWord = pWords[randomNum]
  return secretWord

# ==> Add your subprograms here



# -------------------------------------------
# Main Program
# -------------------------------------------

# Generate secret word 
wordToGuess = generateWord(words)
numAttemptsLeft = len(wordToGuess) + 3

# ==> Add code to complete the task

