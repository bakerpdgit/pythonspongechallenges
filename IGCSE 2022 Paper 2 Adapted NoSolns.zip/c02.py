# IGCSE CS 2022 REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------
# Constants
# -------------------------------------------

STORED_LETTER = "g"

# -------------------------------------------
# Global variables
# -------------------------------------------

letter = ""

# -------------------------------------------
# Main Program
# -------------------------------------------

# input the choice of letter from the user
letter = input("Input a letter ")

# Letter converted to lower case
letter = letter.lower()

# ==> AMEND THE CODE BELOW TO COMPLETE THE IF STATEMENT
if :
    
elif :
    
else: