# IGCSE CS SAMPLE ASSESSMENT REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------------------------------
# Constants
# -------------------------------------------------------------------

INPUT_FILE = "Cities.txt"
OUTPUT_FILE = "Numbered.txt"

# -------------------------------------------------------------------
# Global variables
# -------------------------------------------------------------------

# DO NOT USE any other data structure in your solution.
count = 0               # A counter for the line numbers
theLine = ""            # Holds each line of the file

# =====> Add code for any additional variables used
line = ""
fileIn = None
fileOut = None

# -------------------------------------------------------------------
# Main program
# -------------------------------------------------------------------

# =====> Open the input file
fileIn = open(INPUT_FILE, "r")

# =====> Open the output file
fileOut = open(OUTPUT_FILE, "w")

# =====> Use repetition to read each line of
# the input file into a variable named 'theLine'
for line in fileIn:
  # =====> Increment the line count
  count = count + 1
  # =====> Add the line number to the front of the line followed by a space
  line = "{} {}".format(count, line)
  # =====> print the line to the display (stripped to remove extra new line)
  print(line.strip())
  # =====> Also write the new line to the output file
  fileOut.write(line)

# =====> Close files
fileIn.close()
fileOut.close()