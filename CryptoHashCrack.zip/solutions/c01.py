import hashlib
import itertools
import string

ALPHABET = string.ascii_letters  # a-zA-Z

def sha256_hex(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

def crack_4char_sha256(target_hex: str) -> str | None:
    target_hex = target_hex.lower()
    for chars in itertools.product(ALPHABET, repeat=4):
        pwd = "".join(chars)
        if sha256_hex(pwd) == target_hex:
            return pwd
    return None

TARGET_HASH = "db26909bbd49722250562244208a2d0552a092b9bb62e02613a543abf17ceb39"

found = crack_4char_sha256(TARGET_HASH)
print(found)
