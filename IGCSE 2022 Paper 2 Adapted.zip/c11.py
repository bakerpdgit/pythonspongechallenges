# IGCSE CS 2022 REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------
# Global variables
# -------------------------------------------

FILENAME = "passwords.txt"

#  ==> Add code to initialise variables
totalIncorrect = 0
line = ""
validFirstLetter = False
foundDigit = False
index = 0

# -------------------------------------------
# Main Program
# -------------------------------------------

# ==> Open the file for reading

file = open(FILENAME, "r")

# ==> Process each password in the file
for line in file:
  
  line = line.strip() # not needed on this occasion but good practice
  
  # first check for uppercase first letter
  validFirstLetter = line[0].isupper() 

  # only need to check for digit it it passes the first check
  if validFirstLetter == True:

    foundDigit = False
    index = 0

    # processing loop to check if character is a digit
    while index < len(line) and foundDigit == False:
      if line[index].isdigit() == True:
        foundDigit = True
      index = index + 1

  if validFirstLetter == False or foundDigit == False:
    print(line, "is invalid")
    totalIncorrect = totalIncorrect + 1    

# ==> Close the file
file.close()

# ==> Output the total number of incorrect passwords
print("Total number of incorrect passwords:", totalIncorrect)
