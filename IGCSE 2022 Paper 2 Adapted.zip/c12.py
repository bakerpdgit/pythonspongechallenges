# IGCSE CS 2022 REWRITTEN FOR EDEXCEL CS STYLE

#--------------------------------------------
# Library imports
# -------------------------------------------
import random

# -------------------------------------------
# Global variables
# -------------------------------------------

# Array of words
words = ["antelope","ape","badger","bear","beaver","bison","crocodile","elephant",
         "elk","ferret","goat","goose","kangaroo","llama","lion","monkey","moose",
         "orangutan","shark","snake","tiger","whale","wombat"]

#  ==> Add code to initialise variables
wordToGuess = ""
numAttemptsLeft = 0
guessesUsed = 0
correctLetters = ""
wrongLetters = ""
guessed = False

# -------------------------------------------
# Sub-Programs
# -------------------------------------------

def generateWord(pWords):
  # Fully completed function that generates and returns a secret word
  randomNum = random.randint(0,len(pWords)-1)
  secretWord = pWords[randomNum]
  return secretWord

# ==> add your subprograms here

def getValidGuess(pWord):
  guess = ""
  wordLength = len(pWord)

  # loop to validate input to make sure it is the same Length as the secret word
  while len(guess) != wordLength:
    guess = input("Enter your guess of length {} letters: ".format(wordLength))
  
  # return validated word
  return guess

def checkLettersInWord(pGuess, pWordToGuess, pLetters, pTypeOfCheck):

  # keep the letters in the store so far
  result = pLetters

  # loop to check each guess letter
  for letter in pGuess: 

      if result.find(letter) == -1:
        # The letter is not in the result - now check if we should add it

        if pTypeOfCheck == 0 and pWordToGuess.find(letter) >= 0: 
          # checking for correct letters and it is present so add it
          result = result + letter
        elif pTypeOfCheck == 1 and pWordToGuess.find(letter) == -1:
          # checking for incorrect letters and it is not present so add it
          result = result + letter

  return result

# -------------------------------------------
# Main Program
# -------------------------------------------

# Generate secret word 
wordToGuess = generateWord(words)
numAttemptsLeft = len(wordToGuess) + 3

# Loop until the no attempts are left or the secret word has been guessed
while numAttemptsLeft > 0 and guessed == False:
    
  # output attempts left and reduce this
  print("You have", numAttemptsLeft, "attempts to guess the secret word.")
  numAttemptsLeft = numAttemptsLeft - 1
  
  guess = getValidGuess(wordToGuess)  # Validate the input
  
  if guess == wordToGuess: # Check to see if the secret word has been guessed
    guessed = True        

  else: # If it hasn't been guessed check for correct and wrong letters

    correctLetters = checkLettersInWord(guess, wordToGuess, correctLetters, 0)
    wrongLetters = checkLettersInWord(guess, wordToGuess, wrongLetters, 1)
    
    # output the letters that were present and the letters that were not present
    print("Letter(s) in the secret word:", correctLetters)
    print("Letter(s) not in the secret word:", wrongLetters)

# Display suitable game over message
if guessed == True:
  guessesUsed = len(wordToGuess) + 3 - numAttemptsLeft
  print("Well done. You guessed the secret word in {} guesses!".format(guessesUsed))
else:
  print("Game over. You did not guess that the secret word was", wordToGuess)
