# IGCSE CS 2022 REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------
# Global variables
# -------------------------------------------

#  ==> Add code to initialise variables

Number = 0

#  ==> Initialise any further global variables needed


# -------------------------------------------
# Sub-Programs
# -------------------------------------------

def checkPrime(pNumber):
  #  ==> Add code to complete the subprogram
  result = True

  for current in range(2, pNumber):
    if pNumber % current == 0:
      result = False

  return result

# -------------------------------------------
# Main Program
# -------------------------------------------


Number = int(input("Enter number to check: "))

# ==> Add code to complete the implementation of the flowchart

if checkPrime(Number) == True:
  print(Number, "is prime")
else:
  print(Number, "is not prime")
