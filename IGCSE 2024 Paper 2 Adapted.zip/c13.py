# -------------------------------------------------------
# Global variables
# -------------------------------------------------------
# =====> Write your code here
myString = ""
myNumber = 0
myNewKey = ""

# -------------------------------------------------------
# Subprograms
# -------------------------------------------------------

def genNewKey (pString, pNum):
    newKey = ""        # Make new word here

    # ==> Write your code below this line
    newKey = "{}{}{}".format(pString[0:2], pNum, pString[-2:])
    return newKey

# -------------------------------------------------------
# Main program
# -------------------------------------------------------

myString = input ("Enter a string: ")
myNumber = int (input ("Enter a whole number: "))

if (len (myString) != 4):
    print ("String must be four characters")
else:
    print ("Original: ", myString, myNumber)

    # ==> Complete the call to the subprogram
    myNewKey = genNewKey(myString, myNumber)
    print ("New word:", myNewKey)

