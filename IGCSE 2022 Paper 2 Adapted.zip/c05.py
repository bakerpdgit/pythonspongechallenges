# IGCSE CS 2022 REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------
# Global variables
# -------------------------------------------

FILENAME = "passwords.txt"

#  ==> Add code to initialise variables



# -------------------------------------------
# Main Program
# -------------------------------------------

# ==> Open the file for reading




# ==> Process each password in the file



# ==> Close the file


# ==> Output the total number of incorrect passwords

