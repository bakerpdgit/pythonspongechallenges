# -------------------------------------------------------
# Constants
# -------------------------------------------------------

LAYOUT = "|{:^5}|{:^20}|{:^12}|{:^20}|"

# -------------------------------------------------------
# Global variables
# -------------------------------------------------------

tblWords = [["apple", "banana"],
              ["wrist", "leg"],
              ["blue", "yellow"],
              ["speaker", "keyboard"],
              ["lavender", "tulip"],
              ["pencil", "chalk"],
              ["apartment", "house"],
              ["bottom", "top"],
              ["snow", "fog"],
              ["beach", "mountain"],
              ["", ""]]

word1 = "newspaper"
word2 = "book"

# =====> Write your code here


# -------------------------------------------------------
# Main program
# -------------------------------------------------------
# =====> Write your code here

