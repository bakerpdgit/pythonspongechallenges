# IGCSE CS 2022 REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------
# Global variables
# -------------------------------------------

length = 0.0
area = 0.0

# -------------------------------------------
# Main Program
# -------------------------------------------

# ==> CORRECT THE THREE ERRORS IN THIS CODE

length = float(input("Enter the length of a side ")

area == length * length

print("The area of the square is,area")

# ==> COMPLETE THE COMMENTS BELOW TO ANSWER THE QUESTIONS
# Name a technique used above to improve the readability of the code: 
# What line number contains a syntax error? 
# The other two errors in the code are both of the same type: what type is that? 