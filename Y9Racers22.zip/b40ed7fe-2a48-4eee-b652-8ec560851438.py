##################
# LIBRARY IMPORTS
##################

from sys import stdctx
from dataclasses import dataclass
import time

##################
# GAME OBJECTS
##################

@dataclass
class Car:
    column: int = 0
    row: int = 0
    xDir: int = 0
    yDir: int = 0
    isCrashed: bool = False
    isFinished: bool = False
    facingRight: bool = True

#############
# CONSTANTS
############

SCREEN_HEIGHT = 400
SCREEN_WIDTH = 500
CELL_WIDTH = 40
GRID_SIZE = 6
Y_OFFSET = 50
X_OFFSET = 50
PAUSE_TIME = 0.2
FLAG_X = 5
FLAG_Y = 0
FLAG_URL = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT32Jeq4_RBhjCXAigk2SwYsQVQXwbHI7KfJhyz7Db3ZGfWUNRvu36KrdbbHmoCWF5H9hE&usqp=CAU"
SPRITE_URL = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSjKb9ytJX7DLcVX-FIFp-S-2j-zeT_sf8y3g&usqp=CAU"
SPRITE_FLIP_URL = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBzdGFuZGFsb25lPSJubyI/Pgo8IURPQ1RZUEUgc3ZnIFBVQkxJQyAiLS8vVzNDLy9EVEQgU1ZHIDIwMDEwOTA0Ly9FTiIKICJodHRwOi8vd3d3LnczLm9yZy9UUi8yMDAxL1JFQy1TVkctMjAwMTA5MDQvRFREL3N2ZzEwLmR0ZCI+CjxzdmcgdmVyc2lvbj0iMS4wIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciCiB3aWR0aD0iMjI1LjAwMDAwMHB0IiBoZWlnaHQ9IjIyNS4wMDAwMDBwdCIgdmlld0JveD0iMCAwIDIyNS4wMDAwMDAgMjI1LjAwMDAwMCIKIHByZXNlcnZlQXNwZWN0UmF0aW89InhNaWRZTWlkIG1lZXQiPgo8bWV0YWRhdGE+CkNyZWF0ZWQgYnkgcG90cmFjZSAxLjEwLCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxMQo8L21ldGFkYXRhPgo8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwLjAwMDAwMCwyMjUuMDAwMDAwKSBzY2FsZSgwLjEwMDAwMCwtMC4xMDAwMDApIgpmaWxsPSIjZmYwMDAwIiBzdHJva2U9Im5vbmUiPgo8cGF0aCBkPSJNODkzIDE3NDkgYy00MCAtMTIgLTY3IC0zOSAtMjAwIC0yMDIgLTE3MCAtMjA3IC0xODAgLTIxNyAtMjM5IC0yMTcKLTE0OSAwIC0yNzIgLTQ4IC0zNTIgLTEzNSAtNzUgLTgxIC05MiAtMTM2IC05MiAtMjkxIDAgLTExOSAxIC0xMjYgMjUgLTE0OQoyMiAtMjMgMzEgLTI1IDEyMiAtMjUgbDk4IDAgMTggNDkgYzI1IDcwIDg0IDE0MSAxNDcgMTc1IDYxIDMzIDE1OSA0NSAyMjcgMjcKOTIgLTI1IDE4OSAtMTIxIDIxMyAtMjEyIGwxMSAtMzkgMjUzIDAgMjUzIDAgMjEgNTggYzI0IDY1IDkzIDE0MiAxNTcgMTc1IDU3CjI5IDE3MSAzNSAyMzMgMTIgOTAgLTM0IDE3OSAtMTMxIDE5OCAtMjE3IGw2IC0yOCA5NyAwIGM4NCAwIDEwMiAzIDEyNSAyMQpsMjYgMjAgMCAyNTkgMCAyNTkgLTI2IDIwIGMtMjQgMTkgLTQxIDIxIC0xNDEgMjEgbC0xMTUgMCAtMjkgMzEgYy0xNSAxNyAtODcKMTA5IC0xNjAgMjA0IC05NyAxMjkgLTEzOSAxNzYgLTE2MSAxODQgLTM4IDE0IC02NjkgMTMgLTcxNSAweiBtMjM3IC0yODkgbDAKLTEzMCAtMjAwIDAgYy0xMTAgMCAtMjAwIDMgLTIwMCA2IDAgOCAxMjkgMTY0IDE3OSAyMTcgbDM1IDM3IDkzIDAgOTMgMCAwCi0xMzB6IG01MTYgNSBjNTEgLTY2IDkzIC0xMjMgOTQgLTEyOCAwIC00IC0xMDAgLTYgLTIyMiAtNSBsLTIyMyAzIC0zIDEyOCAtMwoxMjggMTMyIC0zIDEzMyAtMyA5MiAtMTIweiIvPgo8cGF0aCBkPSJNNDg1IDg2MSBjLTk5IC00NiAtMTQxIC0xNTggLTk2IC0yNTYgNzAgLTE1MiAyODIgLTE1MiAzNTIgMCA3NCAxNjEKLTk1IDMzMCAtMjU2IDI1NnoiLz4KPHBhdGggZD0iTTE2MDIgODU5IGMtNDcgLTI0IC04MyAtNjYgLTEwMSAtMTE4IC01MSAtMTUzIDEwNyAtMjk4IDI1NyAtMjM2IDQ5CjIxIDgxIDUyIDEwMyAxMDAgNzYgMTY0IC05OCAzMzMgLTI1OSAyNTR6Ii8+CjwvZz4KPC9zdmc+Cg=="

##############
# GLOBAL VARIABLES
##############

# the main car object
car = Car()
walls = [(1,0), (1,1), (1,2), (1,3), (1,4), (2,4), (3,4), (5,5), (5,4), (5,3), (5,2), (4,2), (3,2), (3,1), (4,1), (5,1)  ]
gameOver = False

#############
# SUBPROGRAMS
#############

def drawBorder(x, y):
  stdctx.strokeStyle = "black"
  stdctx.strokeRect(X_OFFSET + x * CELL_WIDTH, Y_OFFSET + y * CELL_WIDTH, CELL_WIDTH, CELL_WIDTH)  

def drawTrackSquare(x, y):
  stdctx.fillStyle = "#FFFFFF"
  stdctx.fillRect(X_OFFSET + x * CELL_WIDTH, Y_OFFSET + y * CELL_WIDTH, CELL_WIDTH, CELL_WIDTH)
  drawBorder(x, y)

def drawWall(x, y):
  stdctx.fillStyle = "#A0A0A0"
  stdctx.fillRect(X_OFFSET + x * CELL_WIDTH, Y_OFFSET + y * CELL_WIDTH, CELL_WIDTH, CELL_WIDTH)
  

def drawCarSquare(x, y):
  if car.facingRight:
    stdctx.drawImage(SPRITE_URL, X_OFFSET + x * CELL_WIDTH + 1, Y_OFFSET + y * CELL_WIDTH + 1, CELL_WIDTH - 2, CELL_WIDTH - 2)
  else:
    stdctx.drawImage(SPRITE_FLIP_URL, X_OFFSET + x * CELL_WIDTH + 1, Y_OFFSET + y * CELL_WIDTH + 1, CELL_WIDTH - 2, CELL_WIDTH - 2)

  drawBorder(x, y)

def doPause():
  start = time.time()
  while time.time() - start < PAUSE_TIME:
    checkKeys()

def drawTrack():
  for x in range(GRID_SIZE):
    for y in range(GRID_SIZE):
      drawTrackSquare(x, y)
  drawCarSquare(car.column, car.row)
  drawBorder(x, y)
  for x, y in walls:
    drawWall(x,y) 
  drawFlag()
def resetScreen():
  stdctx.fillStyle = "#D0D0D0"
  stdctx.fillRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)

def drawFlag():
  stdctx.drawImage(FLAG_URL, X_OFFSET + FLAG_X * CELL_WIDTH + 1, Y_OFFSET + FLAG_Y * CELL_WIDTH + 1, CELL_WIDTH - 2, CELL_WIDTH - 2)

def checkKeys():
  if stdctx.check_key(39):
    car.xDir = 1
    car.yDir = 0
    car.facingRight = True
  elif stdctx.check_key(37):
    car.xDir = -1
    car.yDir = 0
  elif stdctx.check_key(40):
    car.yDir = 1
    car.xDir = 0
  elif stdctx.check_key(38):
    car.yDir = -1
    car.xDir = 0
def checkCrash():
  if car.column < 0 or car.column >= GRID_SIZE:
    return True
  elif car.row < 0 or car.row >= GRID_SIZE:
    return True 
  if (car.column, car.row) in walls:
    return True
  return False

def animate():
  drawTrackSquare(car.column, car.row)
  car.column += car.xDir
  car.row += car.yDir
  car.isCrashed = checkCrash()
  if car.isCrashed:
    return True
  else:
    drawCarSquare(car.column, car.row)
    stdctx.present()
  if car.column == FLAG_X and car.row == FLAG_Y:
    car.isFinished = True
    return True  

##################
# MAIN PROGRAM
##################

resetScreen()
drawTrack()
stdctx.present()

while not gameOver:
    doPause()
    gameOver = animate() 
if car.isFinished:
  stdctx.fillStyle = "green"
  stdctx.fillText("GAME OVER: VICTORY IS YOURS!!", 10, 20)
  stdctx.present()
else:
  stdctx.fillStyle = "blue"
  stdctx.fillText("GAME OVER: SADLY, YOU HAVE CRASHED!!", 10, 20)
  stdctx.present()


