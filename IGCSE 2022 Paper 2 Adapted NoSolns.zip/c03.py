# IGCSE CS 2022 REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------
# Constants
# -------------------------------------------

PRICE_1 = 20.00
PRICE_2 = 15.00
PRICE_3 = 12.00
SEPARATOR = "+" + "-" * 25 + "+" + "-" * 25 + "+"

#  ==> Add code to initialise additional constants



# -------------------------------------------
# Global variables
# -------------------------------------------

#  ==> Add code to initialise variables

textbookPrice = 0.0
totalCost = 0.0
numberOfTextbooks = 0

# -------------------------------------------
# Main Program
# -------------------------------------------

#  ==> Add code to prompt and take number of textbooks required



#  ==> Add code to generate the price per textbook and the total cost



print(SEPARATOR)

# ==> Add code to output the centred headers

print(SEPARATOR)

# ==> Add code to output the centred calculated values rounded to 2dp

print(SEPARATOR)