
from UI import ROWS, COLS
import UI


############################
# Algorithms
############################

def neighbours(row, col, maze):
    """Returns all valid neighbours"""
    for drow, dcol in [(-1,0),(1,0),(0,-1),(0,1)]:
        newrow, newcol = row+drow, col+dcol
        if 0 <= newrow < ROWS and 0 <= newcol < COLS and maze[newrow][newcol] == 0:
            yield newrow, newcol



def wall_follow(start, end, maze):
    visited.clear()
    DIRS = [(-1,0), (0,1), (1,0), (0,-1)]
    path = []
    row, col = start
    # initial facing: to the right (index 1)
    dir_idx = 1
    while True:
        UI.current = (row,col) # display the current position
        visited.add((row,col)) # store visited and display
        step() # update the ui
        path.append((row,col)) # remember the path
        if (row,col) == end:
            return path # found the end, return path

        # choose direction: check left first, then forward, then right, then back
        for turn in [ -1, 0, 1, 2 ]:  # left, forward, right, back
            ndir = (dir_idx + turn) % 4
            dr, dc = DIRS[ndir]
            nr, nc = row+dr, col+dc
            if 0 <= nr < ROWS and 0 <= nc < COLS and maze[nr][nc] == 0:
                row, col = nr, nc
                dir_idx = ndir
                break


# Task 1: DFS (remove """ before starting (used to hide the syntax errors))
def depth_first(start, end, maze):
    # (coords, path_taken_to_get_there)
    stack = [(start,[start])]
    
    """
    visited.clear()
    seen = {____}
    while len(stack) _ 0:
        cur, path = stack.pop()
        UI.current = cur
        visited.add(cur)
        step()
        if cur __ end:
            return path
        for n in neighbours(*cur, maze):
            if n ___ __ seen:
                seen.add(_)
                stack.append((n,path + [_]))
    """
    return []


# Task 2: BFS
def breadth_first(start, end, maze):
    # (coords, path_taken_to_get_there)
    queue = [(start,[start])]
    
    visited.clear()
    
    """
        UI.current = cur
        visited.add(cur)
        step()
    """
    return []

# Extention, have fun!
def a_star(start, end, maze):
    return []
    



#####################
# Run
#####################


visited = UI.visited
step = UI.step

UI.wall_follow = wall_follow
UI.depth_first = depth_first
UI.breadth_first = breadth_first
UI.a_star = a_star

UI.run()