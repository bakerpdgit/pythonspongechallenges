# IGCSE CS SAMPLE ASSESSMENT REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------------------------------
# Global variables
# -------------------------------------------------------------------

# FIELD STRUCTURE: FIRSTNAME, SURNAME, YEAR OF BIRTH
theArtists = [["Andy", "Warhol", 1928],
              ["Pablo", "Picasso", 1881],
              ["Salvador", "Dali", 1904],
              ["Lavinia", "Fontana", 1552],
              ["Jackson", "Pollock", 1912],
              ["Henri", "Matisse", 1869],
              ["Frida", "Kahlo", 1907],
              ["Georgia", "O'Keeffe", 1887],
              ["Kara", "Walker", 1969],
              ["Yayoi", "Kusama", 1929]
             ]

theLabels = []   # Put the new user labels into this structure

# ======> Add code below
record = []
youngestYear = 0
youngestName = ""

# -------------------------------------------------------------------
# Main program
# -------------------------------------------------------------------

# ======> Add code below

# output message for context
print("New labels generated: ")

# process each artist record
for record in theArtists:

  # build new label, append and output
  newLabel = record[1][0] + record[0][0] + str(record[2])
  theLabels.append(newLabel)
  print(newLabel)

  # Check for younger: note > used here because bigger year of birth means younger person
  if record[2] > youngestYear: 
    youngestYear = record[2]
    youngestName = record[0] + " " + record[1]

# output details of youngest
print("The youngest artist is {} who was born in year {}".format(youngestName, youngestYear))



