# IGCSE CS SAMPLE ASSESSMENT REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------------------------------
# Constants
# -------------------------------------------------------------------

INPUT_FILE = "Cities.txt"
OUTPUT_FILE = "Numbered.txt"

# -------------------------------------------------------------------
# Global variables
# -------------------------------------------------------------------

# DO NOT USE any other data structure in your solution.
count = 0               # A counter for the line numbers
theLine = ""            # Holds each line of the file

# =====> Add code for any additional variables used

# -------------------------------------------------------------------
# Main program
# -------------------------------------------------------------------

# =====> Open the input file

# =====> Open the output file

# =====> Use repetition to read each line of
# the input file into a variable named 'theLine'

  # =====> Increment the line count

  # =====> Add the line number to the front of the line followed by a space

  # =====> print the line to the display

  # =====> Also write the new line to the output file

# =====> Close files