# -------------------------------------------------------------------
# Libraries
# -------------------------------------------------------------------

import time

# -------------------------------------------------------------------
# Global variables
# -------------------------------------------------------------------

TimeDelay = 2

# -------------------------------------------------------------------
# Subprograms
# -------------------------------------------------------------------

def toCelsius (pTemp):
  celsius = (5.0 / 9.0) * (pTemp - 32.0)
  return celsius

def toFahrenheit (pTemp):
  fahrenheit = ((9.0 / 5.0) * pTemp) + 32.0
  return (fahrenheit)

def waitFiveSeconds ():
  time.sleep (5)

def waitTime (pSeconds):
  time.sleep (pSeconds)

# -------------------------------------------------------------------
# Main program
# -------------------------------------------------------------------

print (toFahrenheit (0))
print (toCelsius (212.0))
print ("Sleeping for 5")
waitTenSeconds()
print (toCelsius (32.0))
print ("Sleeping for 2")
waitTime (TimeDelay)
print (toFahrenheit (100.0))

# -------------------------------------------------------------------
# =====> Write your answers here in the right hand column
# Left Column                                           # Right Column
# -------------------------------------------------------------------
# Give the name of a built-in subprogram in the code    # 
# Give the name of one parameter used in a subprogram
                                                        # 
# Give the name of a subprogram that does not use parameters
                                                        #  
# Give the name of a local variable                     # 
# Give the name of a global variable                    # 