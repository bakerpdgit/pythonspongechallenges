# IGCSE CS 2022 REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------
# Global variables
# -------------------------------------------

#  ==> Add code to initialise variables

Number = 0

#  ==> Initialise any further global variables needed


# -------------------------------------------
# Sub-Programs
# -------------------------------------------

def checkPrime(pNumber):
  #  ==> Add code to complete the subprogram


# -------------------------------------------
# Main Program
# -------------------------------------------

Number = int(input("Enter number to check: "))

# ==> Add code to complete the implementation of the flowchart

