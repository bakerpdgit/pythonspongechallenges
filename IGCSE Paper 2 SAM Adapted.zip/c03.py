# IGCSE CS SAMPLE ASSESSMENT REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------------------------------
# Global variables
# -------------------------------------------------------------------

# Each weekly record has two fields: Attendance, Income in that order
weeklyData = [[800, 23000], [1499, 10000], [1600, 47000], [200, 10000]]

# -------------------------------------------------------------------
# Main program
# -------------------------------------------------------------------

# =====> Complete the gaps in the code to implement the algorithm

for record in weeklyData:

  income = 
  attendance = 

  print ("Attendance: ", attendance, " income: ", income)

  if (     ):
    print ("Sufficient profit made this week")
  elif (     ):
    print ("Income in line with attendance this week")
  elif (     ):
    print ("Attendance is very low this week...contact fan club.")
  else:
