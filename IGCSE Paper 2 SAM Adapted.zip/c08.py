# IGCSE CS SAMPLE ASSESSMENT REWRITTEN FOR EDEXCEL CS STYLE

# ---------------------------------
# Global variables
# ---------------------------------

# =====> Add code here
country = ""
numAdults = 0
numChildren = 0
total = 0

# ---------------------------------
# Main program
# ---------------------------------

# =====> Implement the flowchart logic

print("Enter the country you are visiting from:")
country = input()

print("Enter the number of adults in party:")
numAdults = int(input())

print("Enter the number of children in party:")
numChildren = int(input())

total = numAdults + numChildren

print("You are from country:", country)
print("Total number in party:", total)