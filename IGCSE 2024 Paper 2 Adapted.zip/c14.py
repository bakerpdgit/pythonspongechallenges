# -------------------------------------------------------
# Constants
# -------------------------------------------------------

INPUT_FILE = "Sales.txt"    # Output file name
COMMA = ","                 # Use as a constant

# -------------------------------------------------------
# Global variables
# -------------------------------------------------------

subTotal = 0        # Subtotal for each line
grandTotal = 0      # Running total
salesList = []      # The sales from each line

# ==> Complete the code to open the file for reading
theFile = 

# -------------------------------------------------------
# Main program
# -------------------------------------------------------

# Complete the code to read each line of the input file
for line

    # ==> Add a line of code to strip the newline character from the line
    line = line.
    
    # ==> Complete the code to split the line into a set of five strings
    salesList = line.

    subTotal = 0 # Reset the subtotal for the next line
    
    # ==> Add code to sum up each value in the set of five strings


    # ==> Add code to display the subtotal for the line
 

    # ==> Add code to calculate the running total
  

# ==> Add code to display the total of all lines in the file


# Complete the code to close the opened file
theFile.

