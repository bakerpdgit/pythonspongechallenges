# -------------------------------------------------------
# Constants
# -------------------------------------------------------

LAYOUT = "|{:^5}|{:^20}|{:^12}|{:^20}|"

# -------------------------------------------------------
# Global variables
# -------------------------------------------------------

tblWords = [["apple", "banana"],
              ["wrist", "leg"],
              ["blue", "yellow"],
              ["speaker", "keyboard"],
              ["lavender", "tulip"],
              ["pencil", "chalk"],
              ["apartment", "house"],
              ["bottom", "top"],
              ["snow", "fog"],
              ["beach", "mountain"],
              ["", ""]]

word1 = "newspaper"
word2 = "book"

# =====> Write your code here
record = [] # the record with pairs of words
longest = "" # the longer word in each pair
pair1 = "" # the first in a pair of words
pair2 = "" # the second in a pair of words
combined = "" # the combined words without punctuation
correction = "" # corrected ordering where needed

# -------------------------------------------------------
# Main program
# -------------------------------------------------------
# =====> Write your code here

# replace the final blanks
tblWords[-1][0] = word1
tblWords[-1][1] = word2

# output the table header and separator
print(LAYOUT.format("Num", "Pair", "Longest", "Correction"))
print(LAYOUT.format("-"*5, "-"*20, "-"*12, "-"*20))

# loop to process each pair of words
for count in range(0, len(tblWords)):

  # extract words & combine without puncuation
  pair1 = tblWords[count][0]
  pair2 = tblWords[count][1]
  combined = "{} {}".format(pair1, pair2)

  # store the longest of the two words
  if len(pair1) > len(pair2):
    longest = pair1
  else:
    longest = pair2
  
  # create alphabetical ordering correction where needed
  if pair1 > pair2:
    correction = "{} {}".format(pair2, pair1)
  else:
    correction = ""

  # output the formatted row
  print(LAYOUT.format(count + 1, combined, longest, correction))

