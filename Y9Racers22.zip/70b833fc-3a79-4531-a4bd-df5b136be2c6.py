##################
# LIBRARY IMPORTS
##################

from sys import stdctx
from dataclasses import dataclass
import time

##################
# GAME OBJECTS
##################

@dataclass
class Car:
    column: int = 0
    row: int = 0
    xDir: int = 0
    yDir: int = 0
    isCrashed: bool = False

#############
# CONSTANTS
############
gameOn = 1
SCREEN_HEIGHT = 500
SCREEN_WIDTH = 500
CELL_WIDTH = 40
GRID_SIZEX = 10
GRID_SIZEY = 8
level = 1

blockedTiles = []
fakeblockedTiles = []
fakeTiles = []

Y_OFFSET = 50
X_OFFSET = 50
PAUSE_TIME = 0.2
SPRITE_URL_L = "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBzdGFuZGFsb25lPSJubyI/Pgo8IURPQ1RZUEUgc3ZnIFBVQkxJQyAiLS8vVzNDLy9EVEQgU1ZHIDIwMDEwOTA0Ly9FTiIKICJodHRwOi8vd3d3LnczLm9yZy9UUi8yMDAxL1JFQy1TVkctMjAwMTA5MDQvRFREL3N2ZzEwLmR0ZCI+CjxzdmcgdmVyc2lvbj0iMS4wIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciCiB3aWR0aD0iOTAwLjAwMDAwMHB0IiBoZWlnaHQ9IjcyOS4wMDAwMDBwdCIgdmlld0JveD0iMCAwIDkwMC4wMDAwMDAgNzI5LjAwMDAwMCIKIHByZXNlcnZlQXNwZWN0UmF0aW89InhNaWRZTWlkIG1lZXQiPgo8bWV0YWRhdGE+CkNyZWF0ZWQgYnkgcG90cmFjZSAxLjEwLCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxMQo8L21ldGFkYXRhPgo8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwLjAwMDAwMCw3MjkuMDAwMDAwKSBzY2FsZSgwLjEwMDAwMCwtMC4xMDAwMDApIgpmaWxsPSIjMDAwMDAwIiBzdHJva2U9Im5vbmUiPgo8cGF0aCBkPSJNNTEwNyA1NjYwIGMtMjAwIC04NSAtMzE3IC0yNjQgLTMxNyAtNDgzIDAgLTEzMiAzMCAtMjIxIDExMiAtMzM5IDcKLTkgMTAgLTIwIDcgLTIzIC03IC02IC02OCA2IC0xNjkgMzUgLTE2MCA0NSAtMTk3IDQ3IC0zMDAgMTUgLTU0IC0xNiAtMTMyCi0zNyAtMjIwIC02MCAtMzYgLTEwIC04NSAtMjQgLTEwOSAtMzEgLTI1IC04IC01MSAtMTQgLTYwIC0xNCAtOCAwIC0zMyAtNwotNTYgLTE2IC0zMSAtMTIgLTQ0IC0yNSAtNTkgLTU3IC0xMCAtMjMgLTMxIC02OSAtNDYgLTEwMiAtMTUgLTMzIC0zOSAtODUKLTUzIC0xMTUgLTcxIC0xNTYgLTkwIC0xOTggLTEwOSAtMjM1IC0yNCAtNDcgLTcwIC0xMzIgLTEwNiAtMTkzIC0xMyAtMjQgLTIxCi00NiAtMTggLTUwIDExIC0xMCAxNDcgLTQxIDE4NyAtNDIgMzMgMCA0MiA5IDE5NSAxODggODggMTAzIDE3OSAyMTEgMjA0IDI0MQo0MiA1MSA0NSA1MyA4NCA0OCAyMyAtMiA1OCAtMTIgODAgLTIxIDM2IC0xNSAzOCAtMTggMzEgLTQ5IC00IC0xNyAtMTEgLTUwCi0xNSAtNzIgLTQgLTIyIC0xOCAtODMgLTMwIC0xMzUgLTEyIC01MiAtMjYgLTExNyAtMzEgLTE0NSAtNSAtMjcgLTE4IC04OAotMjkgLTEzNSAtMTIgLTQ3IC0yNSAtMTA1IC0yOSAtMTMwIC0xMCAtNTQgLTI4IC0xMzQgLTQ2IC0yMTAgLTEyIC01MiAtNDIKLTE5MSAtNTEgLTIzNiAtMiAtMTEgLTMwIC00NSAtNjEgLTc1IC0zMiAtMzAgLTEyMSAtMTEyIC0xOTcgLTE4NCAtNzcgLTcxCi0xNDQgLTEzNSAtMTUwIC0xNDAgLTE0OSAtMTQxIC0yNTggLTIzNSAtMjcxIC0yMzUgLTkgMCAtMzMgMTMgLTUzIDMwIC0zNCAyNwotMzM4IDI1MiAtNDA3IDMwMCAtMTYgMTIgLTczIDUzIC0xMjUgOTEgLTUyIDM5IC0xMDIgNzUgLTExMiA4MCAtMTEgNiAtNDEgLTQKLTEwOCAtMzcgLTUwIC0yNSAtOTMgLTUxIC05NiAtNTggLTggLTIxIDU2IC0xMzUgMTE4IC0yMTEgNTMgLTY1IDE2NSAtMjEwCjE3NSAtMjI4IDYgLTExIDE1IC0yMiAyMCAtMjYgNiAtMyA0NCAtNTEgODYgLTEwNiA3MiAtOTQgMTMwIC0xNjkgMjY1IC0zNDMKNjUgLTgzIDU4IC04MiAxNzcgLTMzIDM5IDE2IDExMSA0NSAxNjAgNjYgNTAgMjAgOTkgNDAgMTEwIDQ0IDExIDUgNDAgMTYgNjUKMjYgMjUgMTAgNTkgMjMgNzUgMzAgMTcgOCA2NCAyNyAxMDUgNDMgNDEgMTcgMTI3IDUxIDE5MCA3NyA2MyAyNiAxNDkgNjEgMTkwCjc3IDQxIDE3IDEwNyA0MyAxNDUgNTkgODggMzUgMTc2IDYyIDM0MyAxMDMgMTczIDQ0IDIzNiA2MCAzNDUgOTEgNTUgMTYgNjAKMTYgNzggLTEgMTAgLTkgMTkgLTIzIDE5IC0yOSAwIC03IDE0IC00NiAzMSAtODYgMTcgLTQxIDM4IC05MiA0NiAtMTE0IDkgLTIyCjE5IC00OSAyNCAtNjAgNCAtMTEgMTggLTQ1IDI5IC03NSAxMiAtMzAgMjYgLTY0IDMwIC03NSAxMyAtMzEgNzggLTE5MSAxMTIKLTI3NSA2OSAtMTczIDUzIC0xNTcgMTc2IC0xNjkgNDMgLTUgODIgLTQgODggMSAxMyA5IDE4IDM2IDM0IDE2NiAxMSA5MCA2CjE0NiAtMzAgMzYyIC0xMiA2OSAtMjUgMTU3IC0zMCAxOTUgLTUgMzkgLTEzIDk5IC0xOSAxMzUgLTYgMzYgLTE4IDEwNiAtMjYKMTU1IC04IDUwIC0yMSAxMzEgLTMwIDE4MCAtOCA1MCAtMTUgOTcgLTE1IDEwNiAwIDE2IC01NSAzNCAtMTQwIDQ0IC0yNSA0Ci03NiAxMiAtMTE1IDIwIC0zOCA4IC0xMTcgMjEgLTE3NSAzMCAtNTggOSAtMTMzIDIzIC0xNjcgMzEgLTM0IDggLTc1IDE0IC05MgoxNCAtNjIgMCAtNzYgMjQgLTQ3IDc4IDEzIDI1IDI5IDY2IDYyIDE1NSAzNSA5MyA2NyAxNzcgOTMgMjQyIDUgMTEgMjMgNTggNDAKMTA1IDE4IDQ3IDM4IDEwMSA0NiAxMjAgNyAxOSAyMiA1NyAzMiA4NCAxMCAyNiAyNCA1MCAzMSA1MyA3IDMgMzAgLTEgNTAgLTEwCjIwIC04IDYyIC0yNSA5MiAtMzcgMzAgLTExIDY0IC0yNSA3NSAtMzAgMTEgLTQgNzQgLTI5IDE0MCAtNTUgMjEwIC04MSAxOTgKLTc2IDI5OCAtMTE5IDY5IC0yOSA0NCAtNTUgMzUyIDM1OCAyNTMgMzM4IDI5NiAzODkgMzUyIDQxOSAzNSAxOCA1MCAzMiA1NQo1MyAyNyAxMTQgMzUgMTUzIDI5IDE2MSAtMTEgMTYgLTE0MSA3MyAtMTY1IDczIC0xNCAwIC0yOSAtNiAtMzMgLTEyIC03IC0xMgotNTggLTU0IC0xNTkgLTEzMyAtMjEgLTE2IC03NiAtNjIgLTEyMyAtMTAwIC0yNDEgLTE5OCAtNDAzIC0zMjUgLTQxNSAtMzI1Ci03IDAgLTE5IDcgLTI2IDE1IC03IDggLTE2IDE1IC0yMCAxNSAtNCAwIC03OCA0NyAtMTY1IDEwNSAtODYgNTggLTE2MSAxMDUKLTE2NiAxMDUgLTEyIDAgLTM5IDQyIC0zMyA1MiAzIDQgMTcgOCAzMSA4IDcyIDAgMjUwIDEzMCAyOTYgMjE1IDU4IDExMSA3NwoxODAgNzcgMjg1IDAgOTcgLTEzIDE1NSAtNTMgMjQwIC01NSAxMTQgLTE0NSAyMDAgLTI2NiAyNTEgLTU4IDI1IC03OCAyOAotMTcxIDI4IC05NCAwIC0xMTIgLTMgLTE3MyAtMjl6Ii8+CjwvZz4KPC9zdmc+Cg=="
SPRITE_URL_R= "data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBzdGFuZGFsb25lPSJubyI/Pgo8IURPQ1RZUEUgc3ZnIFBVQkxJQyAiLS8vVzNDLy9EVEQgU1ZHIDIwMDEwOTA0Ly9FTiIKICJodHRwOi8vd3d3LnczLm9yZy9UUi8yMDAxL1JFQy1TVkctMjAwMTA5MDQvRFREL3N2ZzEwLmR0ZCI+CjxzdmcgdmVyc2lvbj0iMS4wIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciCiB3aWR0aD0iOTAwLjAwMDAwMHB0IiBoZWlnaHQ9IjcyOS4wMDAwMDBwdCIgdmlld0JveD0iMCAwIDkwMC4wMDAwMDAgNzI5LjAwMDAwMCIKIHByZXNlcnZlQXNwZWN0UmF0aW89InhNaWRZTWlkIG1lZXQiPgo8bWV0YWRhdGE+CkNyZWF0ZWQgYnkgcG90cmFjZSAxLjEwLCB3cml0dGVuIGJ5IFBldGVyIFNlbGluZ2VyIDIwMDEtMjAxMQo8L21ldGFkYXRhPgo8ZyB0cmFuc2Zvcm09InRyYW5zbGF0ZSgwLjAwMDAwMCw3MjkuMDAwMDAwKSBzY2FsZSgwLjEwMDAwMCwtMC4xMDAwMDApIgpmaWxsPSIjMDAwMDAwIiBzdHJva2U9Im5vbmUiPgo8cGF0aCBkPSJNMzUyOSA1NjYyIGMtNzUgLTMzIC0xNjEgLTk1IC0yMDQgLTE0OSAtNDIgLTUxIC05MSAtMTU2IC0xMDUgLTIyMwotMTMgLTU5IC05IC0yMDEgOCAtMjY1IDQyIC0xNzEgMTk3IC0zMjMgMzY1IC0zNTkgMjQgLTYgMjYgLTkgMTcgLTI3IC02IC0xMQotMTkgLTIzIC0yOCAtMjYgLTggLTQgLTg1IC01MyAtMTcwIC0xMTAgLTg1IC01NyAtMTU4IC0xMDMgLTE2MiAtMTAzIC00IDAKLTEzIC03IC0yMCAtMTUgLTcgLTggLTE5IC0xNSAtMjYgLTE1IC0xMSAwIC0zMTAgMjMzIC0zMzQgMjU5IC01IDYgLTE5NSAxNTkKLTIxNSAxNzMgLTIwIDE1IC0xMTEgOTAgLTEzNyAxMTQgLTE0IDEzIC0zNiAyNCAtNDcgMjQgLTIyIDAgLTE1MiAtNTggLTE2MgotNzMgLTYgLTggMiAtNDkgMjkgLTE2MSA1IC0xOSAyMCAtMzUgNDcgLTUwIDYyIC0zNCA5NSAtNTcgOTUgLTY5IDAgLTUgMTYKLTI5IDM1IC01MiAzMyAtNDEgMTQ0IC0xODYgMjMwIC0zMDEgMjM0IC0zMTMgMjgyIC0zNzQgMjk2IC0zNzQgOSAwIDUwIDE0IDkwCjMxIDQxIDE3IDkwIDM3IDEwOSA0NCA4MCAzMSAyNzYgMTA3IDI5NSAxMTUgODIgMzYgMjA4IDgxIDIxOCA3NyA3IC0zIDIwIC0yNwozMSAtNTMgMTAgLTI3IDI0IC02MyAzMiAtODEgOCAtMTcgMTQgLTM0IDE0IC0zOCAwIC00IDE1IC00NiAzNCAtOTQgMzAgLTc2CjU3IC0xNDYgMTAxIC0yNjEgNyAtMTkgMjEgLTU1IDMwIC04MCA5IC0yNSAyNCAtNjMgMzIgLTg1IDggLTIyIDIxIC01MiAyOQotNjcgMjkgLTU0IDE1IC03OCAtNDcgLTc4IC0xNyAwIC01OCAtNiAtOTIgLTE0IC0zNCAtOCAtMTA5IC0yMiAtMTY3IC0zMSAtNTgKLTkgLTEyNSAtMjAgLTE1MCAtMjYgLTI1IC01IC04NSAtMTYgLTEzNSAtMjMgLTE0NCAtMjIgLTEzOCAtMTcgLTE1OCAtMTM4Ci0xMCAtNTYgLTIyIC0xMzAgLTI4IC0xNjMgLTEyIC02NCAtMzUgLTIxNyAtNDkgLTMyNSAtNSAtMzYgLTE4IC0xMjEgLTMwCi0xOTAgLTM4IC0yMjkgLTQxIC0yNjUgLTMwIC0zNTggMTYgLTEzMyAyMSAtMTYxIDM0IC0xNzAgMTEgLTkgMTQ2IDAgMTg0IDEyCjExIDQgMjYgMjMgMzUgNDQgMTYgNDAgNTggMTQ0IDEwOCAyNzAgMTcgNDIgMzYgOTEgNDQgMTA3IDcgMTcgMTkgNDggMjggNzAKMjMgNjIgNzYgMTkzIDEwOCAyNjkgMTYgMzggMjkgNzQgMjkgODEgMCA2IDkgMjAgMTkgMjkgMTggMTcgMjMgMTcgNzggMSAxMDkKLTMxIDE3MiAtNDcgMzQ2IC05MSAxNjggLTQyIDI1NCAtNjggMzQ1IC0xMDUgMzkgLTE2IDEwNyAtNDMgMTUwIC02MCA0MiAtMTcKOTEgLTM3IDEwNyAtNDQgMzEgLTEzIDEyNyAtNTIgMjYzIC0xMDYgNDIgLTE3IDkxIC0zNiAxMDcgLTQ0IDE3IC03IDUwIC0yMAo3NSAtMzAgMjUgLTEwIDU5IC0yMyA3NSAtMzAgMTcgLTggNjQgLTI3IDEwNSAtNDMgNDEgLTE2IDEwOSAtNDQgMTUwIC02MSAxMjUKLTUxIDExNyAtNTIgMTgyIDMxIDE2MCAyMDYgMTk0IDI1MCAyNTcgMzMzIDM4IDUwIDc4IDk5IDkwIDEwOSAxMiAxMSAyMSAyNAoyMSAyOSAwIDUgMTkgMzMgNDMgNjEgMjQgMjggNjUgODAgOTIgMTE2IDI3IDM2IDUyIDY3IDU1IDcwIDM0IDMxIDExMyAxNzcKMTA2IDE5NiAtMyA3IC00NiAzMyAtOTYgNTggLTY3IDMzIC05NyA0MyAtMTA4IDM3IC0xMCAtNSAtNjAgLTQxIC0xMTIgLTgwCi01MiAtMzggLTEwOCAtNzkgLTEyNSAtOTEgLTY5IC00OCAtMzczIC0yNzMgLTQwNyAtMzAwIC0yMCAtMTcgLTQ0IC0zMCAtNTMKLTMwIC0xNiAwIC0xNTAgMTE4IC0zMjMgMjg1IC00MSAzOCAtODEgNzcgLTkwIDg1IC0yMTYgMjAwIC0yNjMgMjQ2IC0yNjYgMjY0Ci04IDQzIC0zOCAxODMgLTUxIDIzNiAtNyAzMCAtMjEgOTEgLTMwIDEzNSAtMTkgODkgLTI3IDEyOCAtNTEgMjMwIC05IDM5IC0yMAo5MCAtMjUgMTE1IC00IDI1IC0xNyA4OCAtMjkgMTQwIC0xMiA1MiAtMjUgMTEzIC0zMCAxMzUgLTQgMjIgLTExIDU1IC0xNSA3MgotNyAzMSAtNSAzNCAzMSA0OSAyMiA5IDU3IDE5IDgwIDIxIDM5IDUgNDIgMyA4NCAtNDggMjUgLTMwIDExNiAtMTM4IDIwNAotMjQxIDE1MyAtMTc5IDE2MiAtMTg4IDE5NSAtMTg4IDUyIDEgMTg0IDM1IDE4OSA0OCAyIDcgLTUgMjQgLTE2IDM5IC00NyA2OQotMTM0IDI0MCAtMjI0IDQ0MyAtMTAgMjUgLTMyIDcyIC00OCAxMDUgLTE1IDMzIC0zNiA3OSAtNDYgMTAyIC0yMCA0MyAtNDAgNTcKLTExNCA3MyAtMTkgNCAtNzEgMTggLTExNSAzMCAtNDQgMTIgLTkzIDI2IC0xMTAgMzAgLTE2IDQgLTY2IDE4IC0xMTAgMzAKLTE2NSA0NiAtMjAwIDQ4IC0zMDUgMTUgLTEzOSAtNDQgLTIyMCAtNjEgLTIyMCAtNDcgMCA2IDE4IDM3IDQxIDcxIDU0IDgxIDc5CjE3MiA3OSAyODcgMCAyMDcgLTEwOCAzODMgLTI5MCA0NzIgLTcxIDM1IC04MCAzNyAtMTkwIDQwIC0xMDcgMiAtMTE5IDAgLTE4MQotMjZ6Ii8+CjwvZz4KPC9zdmc+Cg=="
##############
# GLOBAL VARIABLES
##############

# the main car object
car = Car()

gameOver = False

#############
# SUBPROGRAMS
#############

def levelChange(level,blockedTiles,fakeblockedTiles,fakeTiles):
  if level == 1:
    blockedTiles = [[0,1],[1,1],[2,1],[3,1],[4,1],[5,1],[6,1],[7,3],[8,3],[9,3],[6,3],[3,3],[2,3],[0,5],[1,5],[2,5],[5,5],[6,5],[7,5],[8,5],[9,5],[7,7],[5,6]]
    fakeblockedTiles = [[5,3],[4,3],[7,6],[5,7]]
    fakeTiles = []
  elif level == 2:
    blockedTiles = [[0,2],[1,2],[2,2],[3,2],[4,2],[5,2],[6,2],[7,2],[8,2],[2,5],[3,5],[4,5],[5,5],[7,5],[8,5],[9,5],[7,5],[5,5],[6,5]]
    fakeTiles=[[2,0],[4,1],[7,1],[7,4],[2,4],[4,5],[8,7],[2,6]]
  elif level == 3:
    blockedTiles = [[0,1],[1,1],[2,1],[3,1],[4,1],[5,1],[6,1],[7,1],[8,1],[9,3],[8,3],[7,3],[6,3],[5,3],[4,3],[3,3],[2,3],[2,4],[2,5],[8,6],[8,7]]
    fakeblockedTiles = [[4,6],[4,7],[6,5],[6,4]]
    fakeTiles =[[4,4],[4,5],[6,6],[6,7]]
  elif level == 4:
    blockedTiles = [[1,0],[1,1],[1,2],[1,3],[1,4],[3,0],[3,1],[3,2],[3,5],[3,6],[3,7],[5,1],[5,2],[5,3],[5,4],[5,5],[5,6],[7,7],[7,5],[7,4],[7,3],[7,2],[7,1]]
    fakeblockedTiles = [[1,5],[1,6],[7,6]]
    fakeTiles =[[2,7],[3,4],[5,0],[7,0]]
  if level == 4:
    blockedTiles = [[1,0],[1,1],[1,2],[1,3],[1,4],[3,0],[3,1],[3,2],[3,5],[3,6],[3,7],[5,1],[5,2],[5,3],[5,4],[5,5],[5,6],[7,7],[7,5],[7,4],[7,3],[7,2],[7,1]]
    fakeblockedTiles = [[1,5],[1,6],[7,6]]
    fakeTiles =[[2,7],[3,4],[5,0],[7,0]]
  elif level == 5:
    blockedTiles = [[1,0],[1,2],[1,3],[1,4],[1,6],[2,6],[3,6],[4,6],[5,6],[6,6],[8,6],[8,4],[8,3],[8,2],[8,1],[7,1],[6,1],[5,1],[3,1],[3,2],[3,3],[3,4],[4,4],[5,4],[6,4],[6,3]]
    fakeblockedTiles = [[1,1],[1,5],[7,6],[8,5],[4,1]]
    fakeTiles =[[0,4],[2,0],[3,5],[9,6],[6,2]]
  
  return fakeblockedTiles, fakeTiles , blockedTiles
  
def drawBorder(x, y):
  stdctx.strokeStyle = "black"
  stdctx.strokeRect(X_OFFSET + x * CELL_WIDTH, Y_OFFSET + y * CELL_WIDTH, CELL_WIDTH, CELL_WIDTH)  

def drawTrackSquare(x, y):
  stdctx.fillStyle = "#D0D0D0"
  stdctx.fillRect(X_OFFSET + x * CELL_WIDTH, Y_OFFSET + y * CELL_WIDTH, CELL_WIDTH, CELL_WIDTH)
  drawBorder(x, y)

def drawFakeSquare(x, y):
  stdctx.fillStyle = "#D1D1D6"
  stdctx.fillRect(X_OFFSET + x * CELL_WIDTH, Y_OFFSET + y * CELL_WIDTH, CELL_WIDTH, CELL_WIDTH)
  drawBorder(x, y)

def drawFakeBlockedSquare(x, y):
  stdctx.fillStyle = "#FF1F2A"
  stdctx.fillRect(X_OFFSET + x * CELL_WIDTH, Y_OFFSET + y * CELL_WIDTH, CELL_WIDTH, CELL_WIDTH)
  drawBorder(x, y)

def drawFinishSquare(x, y):
  stdctx.fillStyle = "#11FF11"
  stdctx.fillRect(X_OFFSET + x * CELL_WIDTH, Y_OFFSET + y * CELL_WIDTH, CELL_WIDTH, CELL_WIDTH)
  drawBorder(x, y)


def drawBlockedSquare(x, y):
  stdctx.fillStyle = "#FF0000"
  stdctx.fillRect(X_OFFSET + x * CELL_WIDTH, Y_OFFSET + y * CELL_WIDTH, CELL_WIDTH, CELL_WIDTH)
  drawBorder(x, y)

def drawCarSquare(x, y):
  if car.xDir <0:
    stdctx.drawImage(SPRITE_URL_R, X_OFFSET + x * CELL_WIDTH + 1, Y_OFFSET + y * CELL_WIDTH + 5, CELL_WIDTH - 0, CELL_WIDTH -0)
  else: 
    stdctx.drawImage(SPRITE_URL_L, X_OFFSET + x * CELL_WIDTH + 1, Y_OFFSET + y * CELL_WIDTH + 5, CELL_WIDTH - 0, CELL_WIDTH -0)
  drawBorder(x, y)

def doPause():
  start = time.time()
  while time.time() - start < PAUSE_TIME:
    checkKeys()

def drawTrack():
  z=0
  
  for y in range(GRID_SIZEY):
    for x in range(GRID_SIZEX):
      z=0
      for count in range (len(blockedTiles)):
        if blockedTiles[count][0] == x and blockedTiles[count][1] == y:
          drawBlockedSquare(x,y)
          z=1
      if z==0:
        for count in range (len(fakeblockedTiles)):
          if fakeblockedTiles[count][0] == x and fakeblockedTiles[count][1] == y:
            drawFakeBlockedSquare(x,y)
            z=1
      if z==0:
        for count in range (len(fakeTiles)):
          if fakeTiles[count][0] == x and fakeTiles[count][1] == y:
            drawFakeSquare(x,y)
            z=1
      if z == 0:
        drawTrackSquare(x, y)
      if y == 7 and x == 9 and level != 5:
        drawFinishSquare(x,y)
      elif level == 5 and y == 3 and x == 4:
        drawFinishSquare(x,y)
  drawCarSquare(car.column, car.row)
    
def resetScreen():
  stdctx.fillStyle = "#FF0000"
  stdctx.fillRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)

def checkKeys():
  if stdctx.check_key(39) and car.xDir <=0:
    car.xDir += 1
    car.yDir = 0
  elif stdctx.check_key(37) and car.xDir>=-0:
    car.xDir += -1
    car.yDir = 0
  elif stdctx.check_key(40) and car.yDir <=0:
    car.yDir += 1
    car.xDir = 0
  elif stdctx.check_key(38) and car.yDir>=-0:
    car.yDir += -1
    car.xDir = 0
  #time.sleep(0.1)
  
def checkWin():
  if car.column == 9 and car.row == 8 and level != 5:
    return True
  elif car.column == 4 and car.row == 3 and level == 5:
    return True
  
  
  return False

def checkCrash():
  if car.column < 0 or car.column >= GRID_SIZEX or car.row >= GRID_SIZEY or car.row <0:
    return True
  else:
    for count in range (len(blockedTiles)):
      if blockedTiles[count][0] == car.column and blockedTiles[count][1] == car.row:
            return True
    for count in range (len(fakeTiles)):
      if fakeTiles[count][0] == car.column and fakeTiles[count][1] == car.row:
        return True
  return False

def animate():
  drawTrackSquare(car.column, car.row)
  car.column += car.xDir
  car.row += car.yDir
  car.isCrashed = checkCrash()
  car.hasWon = checkWin()
  if car.hasWon:
    return True
  if car.isCrashed:
    return False
  else:
    drawCarSquare(car.column, car.row)
    stdctx.present()  

##################
# MAIN PROGRAM
##################
while gameOn == 1:
  fakeblockedTiles, fakeTiles, blockedTiles  = levelChange(level,blockedTiles,fakeblockedTiles,fakeTiles)
  car = Car()
  resetScreen()
  drawTrack()
  stdctx.present()
  gameOver = ""
  while gameOver != True and gameOver != False:
    doPause()
    gameOver = animate() 
      
  if gameOver == False:
    stdctx.fillStyle = "blue"
    stdctx.fillText("GAME OVER: SADLY, YOU HAVE DIED!!", 10, 20)
    stdctx.fillText("Press enter to reset, down arrow to exit", 10, 40)
    stdctx.present()
    reset=False
    stdctx.present()
    time.sleep(1)
    while reset == False:
      if stdctx.check_key(13):
        reset=True
      elif stdctx.check_key(40):
        reset=True
        gameOn = 0
    
    stdctx.present()
  else:
    stdctx.present()
    stdctx.fillStyle = "blue"
    stdctx.fillText("GAME Won!!", 10, 20)
    stdctx.present()
    time.sleep(1)
    if level != 5:
      level+=1