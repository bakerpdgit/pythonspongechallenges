# IGCSE CS SAMPLE ASSESSMENT REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------------------------------
# Global variables
# -------------------------------------------------------------------

# FIELD STRUCTURE: FIRSTNAME, SURNAME, YEAR OF BIRTH
theArtists = [["Andy", "Warhol", 1928],
              ["Pablo", "Picasso", 1881],
              ["Salvador", "Dali", 1904],
              ["Lavinia", "Fontana", 1552],
              ["Jackson", "Pollock", 1912],
              ["Henri", "Matisse", 1869],
              ["Frida", "Kahlo", 1907],
              ["Georgia", "O'Keeffe", 1887],
              ["Kara", "Walker", 1969],
              ["Yayoi", "Kusama", 1929]
             ]

theLabels = []   # Put the new user labels into this structure

# ======> Add code below

# -------------------------------------------------------------------
# Main program
# -------------------------------------------------------------------

# ======> Add code below


