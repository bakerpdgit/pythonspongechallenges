# COMPLETE THE BLANKS TO GET PART A WORKING
# THEN SOLVE PART B BY ADAPTING process USING A (DEFAULT) DICTIONARY FOR A MULTISET APPROACH!

from collections import defaultdict

# You can paste in your real data when you have it working
# and then comment out line 26
data = '''\
'''

# FOR EXAMPLE DATA
# PART A should give 21
# PART B should give 40
example_data = '''\
.......S.......
...............
.......^.......
...............
......^.^......
...............
.....^.^.^.....
...............
....^.^...^....
...............
...^.^...^.^...
...............
..^...^.....^..
...............
.^.^.^.^.^...^.
...............'''

data = example_data

def process(board, x):
  splitters = {(x, 0)}
  num_splits, pathways = 0, 0

  while splitters:
    new_splitters = set()
    for (sx, sy) in splitters:
      nsy = sy + 1
      if nsy == len(_______):
        continue
      else:
        if board[nsy][sx] != '_':
          new_splitters.add((sx, nsy))
        else:
          num_splits += 1
          if sx > 0:
            new_splitters.add((sx - 1, nsy))
          if sx < len(board[0]) - 1:
            new_splitters.add(__________)
    splitters = new_splitters

  return num_splits, pathways


def part_a(board, x):
  return process(board, x)[0]


def part_b(board, x):
  return process(board, x)[1]


# construct board
board = [list(line) for line in data.splitlines()]
sx = board[0].index('S')

print(part_a(board, sx))
print(part_b(board, sx))


