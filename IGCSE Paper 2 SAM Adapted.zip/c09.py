# IGCSE CS SAMPLE ASSESSMENT REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------------------------------
# Global variables
# -------------------------------------------------------------------

# Each weekly record has two fields: Attendance, Income in that order
weeklyData = [[800, 23000], [1499, 10000], [1600, 47000], [200, 10000]]

# -------------------------------------------------------------------
# Main program
# -------------------------------------------------------------------

# =====> Complete the gaps in the code to implement the algorithm

for record in weeklyData:

  income = record[1]
  attendance = record[0]

  print ("Attendance: ", attendance, " income: ", income)

  if (attendance >= 1500 or income >= 45000):
    print ("Sufficient profit made this week")
  elif (attendance >= 750 and income >= 22500):
    print ("Income in line with attendance this week")
  elif (attendance < 500):
    print ("Attendance is very low this week...contact fan club.")
  else:
    print ("Possible accounting error")
