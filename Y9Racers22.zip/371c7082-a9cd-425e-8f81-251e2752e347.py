# COPY YOUR CODE OVER FROM THE PREVIOUS PAGE.

##################
# LIBRARY IMPORTS
##################

from sys import stdctx
from sys import stdaud
from dataclasses import dataclass
import time
import math

##################
# GAME OBJECTS
##################

@dataclass
class Car:
  column: int = 0
  row: int = 0
  xDir: int = 0
  yDir: int = 0
  isCrashed: bool = False
  isFinished: bool = False
  facingRight: bool = True
  coinScore: int = 0

#############
# CONSTANTS
############

SCREEN_HEIGHT = 400
SCREEN_WIDTH = 500
CELL_WIDTH = 40
GRID_SIZE = 6
Y_OFFSET = 50
X_OFFSET = 50
PAUSE_TIME = 0.2
SPRITE_URL = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTUnzIr8r3jP1igIkdtL5P3MOeCk6WvXaSi35lkuxRHTSX2RFxahA1C_hdugTh2J1IA7U&usqp=CAU"

SPRITE_FLIP_URL = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRTUnzIr8r3jP1igIkdtL5P3MOeCk6WvXaSi35lkuxRHTSX2RFxahA1C_hdugTh2J1IA7U&usqp=CAU"

FLAG_URL = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTkhtZ-2upYHMaBLjRsLAofH4pJYCDiUyfaaOawj92Tajge956mnK1iBkgOh7lxEuERgO4&usqp=CAU"

COIN_SOUND = "data:audio/mpeg;base64,//MkZAABOANqPKAIAQKwAtGBQBAAEIMAA//VqlKeUAJDD+IIY6NiwQk1/9xXDPJA//MkZAYB2GduAMAoAAOwowABgTgADMjAFicvRuWf+PJEHzf/PB/oHZoPr76F/683//MkZAMBpE9iAODAAIM4ntjBxYAB/+/ZEprgSRHzyYRP9QtdP/9/rog00QUAfX8A//MkZAQBcE99IAAnKANonujAAMRMPsF5df/oFmFgGsJ4QuPCv/64AO70qg4BMyt///MkZAUBqGd2VACmPINQzvgAAkpk//wmC/+jQQNAOs9mtQyt//wg//dRCv/qARFL//MkRAUBqGdwACgNYgNYntgAAs5EP79crf/x8CVrYAEOJZu3/82oCSfxNf+lANDb//MkRAUBjGlyACgKYgL4zuAAaATEsy/T/8ZAhv/9YfTVB7uh+QV/8ZXqCQjS6//+//MkZAcBnGl0AAEHMgPA0vgAAwRkUf/1Cb8o1V0BZWWqQxU//1/+or8iXh9Ne3////MkRAYBXGl8AAGlOAIISvQAAF5gv/9Qz9BYgyCr/0//l//x6wGDJ//hr6/z3/6C//MkZA4BbCN2AKOIAAMISvQBTQAAbh1IKDHf/7fiev5ROgQzcBahvXBZvtQr6Gf+//MkRBECcHdqAMOIAAUw7tgBjSgAwrktSXM6segQxeNsIHlKX8Q////jB2WqTEFN//MkZAMAAAGkAOAAAAAAA0gBwAAARTMuMTAwqqqqqqqqqqqqqqqqqqqqqqqqqqqq"

FLAG_SOUND = "data:audio/mpeg;base64,SUQzAwAAAAAAMVRYWFgAAAAnAAAAU29mdHdhcmUATWl4Y3JhZnQgNy41IDY0LUJpdCBCdWlsZCAyOTL/8yRkAAFQAVLQoAgAAgAGOAFBAAANNgQeS1OIf7+mxQfB/BCHxGH1/ZnUeKdQQZz/8yRkCAIQa3AAwogAA5CWwAGHEAFeZ//14dOV+C61yRrjvcCg5x7mV/+IzfUHNx7/8yRkBAHEQ3QA4ogAAqBSxAHHAAASAurwvfL9Bv+K/NT0BbbhU/J4/LL1IK8VQDb/8yRkBgGcZ3gAFAKCA1hSzAABxhAg9XV/P5+PoGPQIm+j7cTa+/dv+yqgycChcVn/8yRkBgF8K3gAAEYGA4CCzAABxAzbS3wF/9WUH/gr8I/q3xvqfu3fIQgYUFrwsFv/8yRkBwG8J3qkAEIAA4CC0AABxBSNBD8xu2fRqGvQBHxN+N8fVqfv/yCoE/DQHxr/8yRkBgHoQXgAAEUEAxiG0AABTgTRJlbs/j/+/+TxoE+A/483o3yHbkdFMaZKsBP/8yRkBQHwQXYAACUCAzhS0AAATgBUQ7W0/HaO7f/ajAGfg4+PtkMV0an//SpUvH7/8yREAwGkKXQAAEcCAuA67AAAxAQbbdirkLMvq//0WVMfj72o8v+7ds9FjHEjhLz/8yREBQFgQXIAAOIGAoBG7AAAhAAco6N/wWuMgmI5eDqddnPognOA+BYZYjyv7v//8yRkCwF8HXoAAGICAsCG2AABTgTTqCfB18o/y/yH6dAnSK4DnmEvLaBfhD8pyeX/8yRkDwD8HXwAACIAAqhS2AAAjgT/f/6KUZKizy1f93//3f06EqcQPpT6/hP3/+j/8yRkFwFsA3oAACIAAuiC0AABxAzI7qfXgv9v///6wv5+B8FT8b4O7kLJzSKPFIv/8yRkGwFII34ABAIAAqCG3MAABAB////f/UG3GXEcM3EOW9Xu/ppf4YtIbPsHGd3/8yRkIQFsE4AABCIAAwhK3MgARCTb268XwY3U/Ot5D/99zbj4kXOKOs2f1//od8P/8yRkJAFcI3oAAMICArBG0AAABADTP5P4850dKnMOKNExeoLqf/R///rmubhv7v//8yRkKQGAFXwABGICAliG0AAARDRH//rqeqUsVwCInf///v/qkuXh/fn2/0//+qr/8yRkLgGoI3YABGIQAkBG1AAARCR5Azhj4dxd19tn//7v6gUUFykq/vzn///9NXz/8yRkMgGAG3QABGICApBG0AAARCRheBwLqF1Pvut//939dx+B8Kdb8/7ej//1qhj/8yRkNgHAG3QABKYEAtgm0MAABAAPqEuATZHxm+//9X3/1ii4Thna37P///6Kfin/8yRkNwHMI3IAFAUgAvBGwAAAjijggBckSCACYrf//lxSQYzT5hDAPLZPXZlIfnT/8yRkNwHcK3IAAKUAAqhGwAAARCRj5EBCS9Ct+n/2eiFSsFAtXxryV5aTfhYInDj/8yRkOAG4G3YABGICArhKzMAAzCSQT4VqDQ/P//rLOTXcKF5G2i/Kd+jBgTcHQfD/8yRkOgHoIXxkBGAUArBa0AAASiRWFMx//YGH9nBsp1LUXZXu0tRQ3Cuo+Geg57P/8yRkOwHIM3YABKIAAvBC3MAASiTbt364y/icNfQb9vx+3VUw3RwY+Deo68fp7///8yRkPAFsJXwAAEIAAuBa0AAAjiT+pR/iE6vKHdOtmnt1qnwRaUgzi7e/R/7v9C//8yRkQAGwL3oAAEAKAriS0AABxCjQLFPoP+/43RV8MQE8T4ZoNx2t2j/3/6QbQqH/8yRkQgGwLXoAAEISAuhW0AAAjiSU6j63Zf9Cg4IeP0GmUK3af//6AAoYV/oHbYP/8yRkQwGEHXoABCICAlCW1AABRCg343LVCNTQeI4ITwV7ZDsX6iYM16kMV7v+lYn/8yRkSAHYLXgABEUEAnha5MgBRGJQGU/DHqc89Z3f9S/hIXq/E6n//3f6FXo1ocv/8yRkSgGIIXwAAEAGAsh63YABxCgKbROLt1dKP+3/SBARahI1YyovdlF8drhzye//8yRkTQFoJ3xgACIAApBe0AABwDD5Av7+W9Ps/0BXXB+r8Ht+N6fIKnidx7mGvTL/8yRkUgGEH3gAAKICAsha1AABRCgPfpogBW9pnqO8p7P/6YmweKwY6nDavqIvXR//8yRkVQHUKXYABMUQAog+1WAADgD3dOMFerVlGv9Cfc/qfActeEhPq+gYZaqfb7v/8yRkVwHUKXgACMUSAqB65MABRCSjMBd41HMN1nuueJVwwZqPwY33f/lglxgQ11D/8yRkWAEwF3gABEYAAuAq3AAATCBqruS72ZpmoeQIqdANdQ08xKbeoOEGNT4JblD/8yRkXgHkJ3pkBEYIArh21AAATiBDelV8DZaBDhYNmpes3TX/z9MEoNDVWh43znX/8yRkXwHYK3YACMISAkBS1AABxCR7FcHPcF1ZwB4X4X4hkqtn+hkp4IZwGOmW+3//8yRkYgFwK3QABKISApg+0KAAEALSUxGkFIKhzZZaDjCLRYAAKIDBOFrf4c/ydS//8yRkZwHQIXrABGUCAnBWyMAAxCYMREBUTZFIGqVEitT/NbPuuJHeu6z/3CN9Sgv/8yRkaQHcIXIABEUAApgqxEAABAAMB+OOu+j9EHKun437PoQeF/+gn63//JfXKpz/8yRkagHoM3RgBMUAAqgqxMAARADQAYQWhipkKvIwJ2Y25/5ejwkz9Pof/4z/8H//8yRkawGIH3gAJCYQAwgi3kAARgD/LAeGCSL0hN428SlUCrvvw3t1fXZ3mVAjelP/8yRkbQHwG34AMGMCgrg+zAAARAToM/LO9bPkPooqhaE+MnlyvuvuQf14Wf1b7fH/8yRkbQHwN34AMGIWAphq4DAARGAH/+O+tKfnwlJ1+o//43xv2fTVKoImKBJ2YWD/8yRkbgI4J3wAPSMAA0jS2AgASkAW6zEixKa3Z/PfEf1tYLuSXTCFGFa1fyv7viP/8yRkagJMG3oALEkQA8hq0AAIDgD6lRlA0HM2prAMdpFaCHmX0b6fVv/itPMw0sD/8yRkYwLQZ3YAPYUGA2jS1AAoBSD90XCmKS9X9S3/7/rVKIH6TgHEWVtIF5L0BVv/8yRkWQKgI3QAPMMAA9BmzAAwTgB/R//t/+N+rkwwDVlMHxzR6u7/6vzifYiLLA3/8yRkTwLMZ24APGISA7hqzAA4zgS1El1HI1qMIWzf/8R/uoqD4ZNkEZiqGB6XI///8yRkRAKwaWwAPMIIA4hG0ABITAjt+WqOIwf8Rdm5dNXEbivX/+rUBUYU+6ZwZIH/8yRkOwJYI2oAYWMCA/BKyABIkghH3f7Pp/bVU4oYg3GWa9LIBNgj7f/2//SkPnj/8yRkMwH8I2wAPEkAA5BGzAAxUChn3zcboulHbv/iyi+NrtHZs4/1uwMO////6xH/8yRkLwIkKWwAPMMAA1BG0ABIhgTCE0+t75Nq05/tx//11ReDLj9UJwFHtkwcZ///8yREKwHgKW4AMCgEA4jS3ABQBOjlP/wzWQdOvLA5rRrP/+/6vqUazVwFW+l5gzH/8yRkKAIcJ2wALCoSA2hS1AAYUihxG//7f/qrgIufVjoMm43//eoDz2jUf4XSY6P/8yRkJAHoKW4AMCsEAshS1AAYRigWxQwmtchNdnjbv/9FD7oJ2gqW6D5f/93/1wf/8yRkJAFAKXAAJEkGAuhOzAAQkgwSNN8liE2KX9SaFa0r8WqewVT/NA43/0zhtgv/8yRkKQGcNXIAJAcEArBq0AAYDiCDWUfE3///6hWu8WbzhOhNREL+UAq0jebV4wf/8yRkLAG0N2wALAoSAthS1AAQBCT6hlUVl7Ep30WLng8Z4yYyV21yPMLwv///+tX/8yRkLgG0N2oALCcGAeBq2AAICiQLHuzRthJIkGeMA6jBy4ksLDfERJULB0PmFlL/8yRkMwGANWgALCoCAtBS1AAIBCCnSN4/ik6gIIvoZ2jQXdBCHCw7v/aRKJy3iEb/8yRkNgFkNWwAFAUSAkhqzAAQCiiUB4739h28yBxfx0EaagXDubq0q3kIQMFnuTr/8yRkPAF8N2gAFA0SAsBqyAAQDkATBNP9BFVOEe1Dsq1flAKsFtTv51UL+JB//9D/8yRkQAFkNWoAGCcIAwhuvAAYDkBA0rvHf28FBLphgFmK2mqx0v54bhwN3+1BNcn/8yRkQwEsN2xQGAoEAjBqwAAoBEAjXk4MwGaUxV8ebqX8FQdUVQg7N0iu9tvHwS//8yRkSwE8N2xgCAcSAsBuwAAoShD///UZUHm6EZHlH8GRNoUEKtkXaJt4WLf///r/8yRkUQEoNWYAFAcSAqBqyMAoDiT5hHMQld8ZjBTwsMUQu03sXNmNEdvCqChosSb/8yRkWAFsNWAAHC1CAvBuuAAwThDteonDNCMY+CQQ6nZZzCaJSFvMCFoJCWvFjUH/8yRkWwGkNWIACAcgAthqtAAIlGRfUTDtNQkHWXyo1T4UHf///1FCvvLg2hR/KBv/8yRkXQGINWYACAUSAtBqwMAQCkCqCRlk/dHkvFQF3////XEDm1fpkOYO+Rhs6Ej/8yRkYAGQN1wAGAoAAthqtAAR1KAbInxmrh2/TBqyERuVveJi/iERKhhl6YFIlq//8yRkYwF4N1wAGCoIAqhutAAQThAQ/BUVTEOofNSGWUwYTxiCTRnl+nSW5XIX8Yj/8yRkZwGUNV4ADCUIAmBqtAAIlGhxjuDfI8qNFK/ygZYYwsH3ydm5V/MCFv/oOM3/8yRkawGsNVwACCcKAuhurAAYVAR0GRUJThnhQ1VEdAf5q+aX8QA9mzIQQ7bkPOj/8yRkbQFQN1oADEsKAnBqrAAIDiQsM9Aa6iU9zfpur2o/i4N3//1kBwFKntQ2U8L/8yRkcwGENVYADCcEAvBuoAAQVAg/ExIBhvigd8VL46WAV+IpH/8sAor5jeNAvl3/8yRkdgFoN1YADAogArBuqAAJjoQmBFvzUyX6FflqTEFNRTMuMTAwqqqqqqqqqqr/8yRkewGgN1YACCoWApBqoAAIShCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/8yRkfgFgNVQAGCcGAthumAAJTqCqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/8yRkggGsN1QApQAAAuhqnAFFAACqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/8yREhAH8OUQAwpwABGh6jAGFaACqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqr/8yRkfQAAAaQA4AAAAAADSAHAAACqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqo="


FLAG_X = 3
FLAG_Y = 4

##############
# GLOBAL VARIABLES
##############

# the main car object
car = Car()

gameOver = False
walls = [(5,0), (1,1)]
fake_walls = [(2,1), (3,1), (5,2), (3,4)]
coins = [(3,2), (4,2)]

#############
# SUBPROGRAMS
#############

def drawCoin(x, y):
  centre_x = X_OFFSET + x * CELL_WIDTH + CELL_WIDTH // 2
  centre_y = Y_OFFSET + y * CELL_WIDTH + CELL_WIDTH // 2
  stdctx.strokeStyle = "black"
  stdctx.fillStyle = "#FFD700" # gold
  stdctx.beginPath();
  stdctx.arc(centre_x, centre_y, CELL_WIDTH//2 * 0.8, 0, 2 * math.pi)
  stdctx.stroke()
  stdctx.fill()

def drawBorder(x, y):
  stdctx.strokeStyle = "black"
  stdctx.strokeRect(X_OFFSET + x * CELL_WIDTH, Y_OFFSET + y * CELL_WIDTH, CELL_WIDTH, CELL_WIDTH)  

def drawTrackSquare(x, y):
  stdctx.fillStyle = "#FFFFFF"
  stdctx.fillRect(X_OFFSET + x * CELL_WIDTH, Y_OFFSET + y * CELL_WIDTH, CELL_WIDTH, CELL_WIDTH)
  drawBorder(x, y)

def drawWall(x, y, col):
  stdctx.fillStyle = col
  stdctx.fillRect(X_OFFSET + x * CELL_WIDTH, Y_OFFSET + y * CELL_WIDTH, CELL_WIDTH, CELL_WIDTH)
  drawBorder(x, y)  

def drawFlag():
  stdctx.drawImage(FLAG_URL, X_OFFSET + FLAG_X * CELL_WIDTH + 1, Y_OFFSET + FLAG_Y * CELL_WIDTH + 1, CELL_WIDTH - 2, CELL_WIDTH - 2)

def drawCarSquare(x, y):
  if car.facingRight:
    stdctx.drawImage(SPRITE_URL, X_OFFSET + x * CELL_WIDTH + 1, Y_OFFSET + y * CELL_WIDTH + 1, CELL_WIDTH - 2, CELL_WIDTH - 2)
  else:
    stdctx.drawImage(SPRITE_FLIP_URL, X_OFFSET + x * CELL_WIDTH + 1, Y_OFFSET + y * CELL_WIDTH + 1, CELL_WIDTH - 2, CELL_WIDTH - 2)
  drawBorder(x, y)

def doPause():
  start = time.time()
  while time.time() - start < PAUSE_TIME:
    checkKeys()

def drawTrack():
  for x in range(GRID_SIZE):
    for y in range(GRID_SIZE):
      drawTrackSquare(x, y)
  for x, y in walls:
    drawWall(x, y, "#A0A0A0")
  for x, y in fake_walls:
    drawWall(x, y, "#C0C0C0")
  for x, y in coins:
    drawCoin(x, y)    
  drawFlag()
  drawCarSquare(car.column, car.row)
    
def resetScreen():
  stdctx.fillStyle = "#D0D0D0"
  stdctx.fillRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)

def checkKeys():
  if stdctx.check_key(39):
    car.xDir = 1
    car.yDir = 0
    car.facingRight = True
  elif stdctx.check_key(37):
    car.xDir = -1
    car.yDir = 0
    car.facingRight = False
  elif stdctx.check_key(38):
    car.yDir = -1
    car.xDir = 0
  elif stdctx.check_key(40):
    car.yDir = 1    
    car.xDir = 0 
  
def checkCrash():
  if (car.column, car.row) in walls:
    return True
  elif car.column < 0 or car.column >= GRID_SIZE:
    return True
  elif car.row < 0 or car.row >= GRID_SIZE:
    return True
  return False

def animate():
  drawTrackSquare(car.column, car.row)
  car.column += car.xDir
  car.row += car.yDir
  car.isCrashed = checkCrash()
  if car.isCrashed:
    return True
  else:
    drawCarSquare(car.column, car.row)
    stdctx.present()  
  if car.column == FLAG_X and car.row == FLAG_Y:
    car.isFinished = True
    return True
  if (car.column, car.row) in coins:
    stdaud.play()
    car.coinScore += 1
    coins.remove((car.column, car.row))

##################
# MAIN PROGRAM
##################

stdaud.load(COIN_SOUND)
resetScreen()
drawTrack()
stdctx.present()

while not gameOver:
    doPause()
    gameOver = animate()  

if car.isFinished:
  stdctx.fillStyle = "green"
  stdctx.fillText(f"GAME OVER: VICTORY IS YOURS WITH {car.coinScore} OUNCE(S) OF METH!!", 10, 20)  
  stdaud.load(FLAG_SOUND)
  stdaud.play()
else:
  stdctx.fillStyle = "red"
  stdctx.fillText("GAME OVER: SADLY, YOU GOT CAUGHT!!", 10, 20)
stdctx.present()

