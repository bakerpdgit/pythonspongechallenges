# -------------------------------------------------------
# Global variables
# -------------------------------------------------------
count = 0
total = 0
subTotal = 0

# -------------------------------------------------------
# Main program
# -------------------------------------------------------

# Loop for 50 times
while (count < 50):
    total = total + count

    if ((count > 10) and (count < 20)):
        subTotal = subTotal + count

    count = count + 1

print (total, subTotal)

# -------------------------------------------------------
# =====> Write your answers here in the right-hand column
# Left                                          # Right
# -------------------------------------------------------
# Give the text of a line that creates 
#      and initialises a variable               # count = 0 // total = 0 // subTotal = 0
# Give the keyword that starts the              
#      selection used in the code               # if
# Give the logical operator used in the code    # and
# Line number(s) for a repetition construct     # 8 // 8 - 14
