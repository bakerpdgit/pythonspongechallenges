# Handles the UI and game logic
# Horrible code readability, blame chatgpt



from sys import stdctx
import random
from time import sleep

####################################
# maze GENERATION
####################################

def generate_maze(rows, cols):
    maze = [[1 for _ in range(cols)] for _ in range(rows)]
    directions = [(-2,0),(2,0),(0,-2),(0,2)]

    def in_bounds(r, c):
        return 0 <= r < rows and 0 <= c < cols

    def carve(r, c):
        maze[r][c] = 0
        random.shuffle(directions)
        for dr, dc in directions:
            nr, nc = r + dr, c + dc
            if in_bounds(nr, nc) and maze[nr][nc] == 1:
                maze[r + dr//2][c + dc//2] = 0
                carve(nr, nc)

    carve(0, 0)
    return maze

ROWS, COLS = 21, 21
maze = generate_maze(ROWS, COLS)

#############
# GUI
#############

SCREEN_HEIGHT = 500
SCREEN_WIDTH = 700
X_OFFSET = 20
Y_OFFSET = 20
BORDER_COLOUR = "#000000"
BACK_COLOUR = "#F0F0F0"
WALL_COLOUR = "#000000"
EMPTY_COLOUR = "#FFFFFF"
START_COLOUR = "#00FF00"
END_COLOUR = "#FF0000"
MARKER_COLOUR = "#0000FF"
PATH_COLOUR = "#FFFF00"
VISITED_COLOUR = "#ADD8E6"
CURRENT_COLOUR = "#FF00FF"   # magenta


CELL_WIDTH = min(
    (SCREEN_WIDTH//2 - 2*X_OFFSET) // COLS,
    (SCREEN_HEIGHT - 2*Y_OFFSET) // ROWS
)

start = None
end = None
marker_row, marker_col = 0, 0
path = []
visited = set()
current = None               # current node being explored
manual_step = False

############################
# GUI SUBPROGRAMS
############################

def draw_cell(row, col, value):
    x = X_OFFSET + col * CELL_WIDTH
    y = Y_OFFSET + row * CELL_WIDTH

    # base fill
    if value == 1:
        stdctx.fillStyle = WALL_COLOUR
    else:
        stdctx.fillStyle = EMPTY_COLOUR
    stdctx.fillRect(x, y, CELL_WIDTH, CELL_WIDTH)

    # overlay visited
    if (row, col) in visited and (row, col) not in (start, end):
        stdctx.fillStyle = VISITED_COLOUR
        stdctx.fillRect(x, y, CELL_WIDTH, CELL_WIDTH)

    # overlay path
    if (row, col) in path and (row, col) not in (start, end):
        stdctx.fillStyle = PATH_COLOUR
        stdctx.fillRect(x, y, CELL_WIDTH, CELL_WIDTH)

    if current == (row, col) and (row, col) not in (start, end):
        stdctx.fillStyle = CURRENT_COLOUR
        stdctx.fillRect(x, y, CELL_WIDTH, CELL_WIDTH)

    # overlay start/end
    if start == (row, col):
        stdctx.fillStyle = START_COLOUR
        stdctx.fillRect(x, y, CELL_WIDTH, CELL_WIDTH)
    elif end == (row, col):
        stdctx.fillStyle = END_COLOUR
        stdctx.fillRect(x, y, CELL_WIDTH, CELL_WIDTH)

    stdctx.strokeStyle = BORDER_COLOUR
    stdctx.strokeRect(x, y, CELL_WIDTH, CELL_WIDTH)

def draw_marker():
    x = X_OFFSET + marker_col * CELL_WIDTH + CELL_WIDTH//4
    y = Y_OFFSET + marker_row * CELL_WIDTH + CELL_WIDTH//4
    stdctx.fillStyle = MARKER_COLOUR
    stdctx.fillRect(x, y, CELL_WIDTH//2, CELL_WIDTH//2)

def draw_instructions():
    stdctx.fillStyle = "#000000"
    stdctx.font = "11px sans-serif"
    base_x = SCREEN_WIDTH//2 - 30
    base_y = 60
    if start is None:
        lines = ["Use arrow keys to move",
                 "Press Enter to set START (green)"]
    elif end is None:
        lines = ["Move marker with arrow keys",
                 "Press Enter to set END (red)"]
    else:
        lines = ["Press W for Wall follow",
                 "Press B for BFS",
                 "Press D for DFS",
                 "Press A for A*",
                 "Press M for manual steps",
                 "Press S for auto steps",
                 "Press space to step",
                 "Press N for new maze",
                 "Or select a new start and end point"]
    for i, line in enumerate(lines):
        stdctx.fillText(line, base_x, base_y + i*24)

def reset_screen():
    stdctx.fillStyle = BACK_COLOUR
    stdctx.fillRect(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)

def update():
    reset_screen()
    for row in range(ROWS):
        for col in range(COLS):
            draw_cell(row, col, maze[row][col])
    draw_marker()
    draw_instructions()
    stdctx.present()

def step():
    global manual_step
    update()
    while manual_step:
        if stdctx.check_key(32): # space
            sleep(0.2)
            break
        elif stdctx.check_key(ord("M")):
            manual_step = True
        elif stdctx.check_key(ord("S")):
            manual_step = False
    if stdctx.check_key(ord("M")):
        manual_step = True
    elif stdctx.check_key(ord("S")):
        manual_step = False
    sleep(0.01)


############################
# Input handling
############################

def get_key():
    global marker_row, marker_col, start, end, path, manual_step, maze
    if stdctx.check_key(37):   # left
        marker_col = max(0, marker_col - 1)
    elif stdctx.check_key(39): # right
        marker_col = min(COLS-1, marker_col + 1)
    elif stdctx.check_key(38): # up
        marker_row = max(0, marker_row - 1)
    elif stdctx.check_key(40): # down
        marker_row = min(ROWS-1, marker_row + 1)
    elif stdctx.check_key(13): # Enter key
        if start is None:
            start = (marker_row, marker_col)
        elif end is None:
            end = (marker_row, marker_col)
        else:
            start, end = (marker_row, marker_col), None
            path = []
            visited.clear()
    elif stdctx.check_key(ord('B')) and start and end:
        path.clear()
        visited.clear()
        path[:] = breadth_first(start, end, maze)
    elif stdctx.check_key(ord('D')) and start and end:
        path.clear()
        visited.clear()
        path[:] = depth_first(start, end, maze)
    elif stdctx.check_key(ord('A')) and start and end:
        path.clear()
        visited.clear()
        path[:] = a_star(start, end, maze)
    elif stdctx.check_key(ord('W')) and start and end:
        path.clear()
        visited.clear()
        path[:] = wall_follow(start, end, maze)
    elif stdctx.check_key(ord("M")):
        manual_step = True
    elif stdctx.check_key(ord("S")):
        manual_step = False
    elif stdctx.check_key(ord("N")):
        maze = generate_maze(ROWS, COLS)


##############
# MAIN
##############

breadth_first = None
depth_first = None
a_star = None
wall_follow = None

update()
def run():
    while True:
        get_key()
        update()
        sleep(0.05)
