# IGCSE CS SAMPLE ASSESSMENT REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------------------------------
# Constants
# -------------------------------------------------------------------

# ======> Add code below
NO_DISCOUNT_MAX = 300
DISCOUNT_LEVEL = 10

# -------------------------------------------------------------------
# Global variables
# -------------------------------------------------------------------

spend = 0.0

# ======> Add code below
finalPrice = 0.0

# -------------------------------------------------------------------
# Sub-Programs
# -------------------------------------------------------------------

def calculateFinalPrice(pSpend):
  # ==> complete this subprogram to return the final price
  calcPrice = 0.0

  if pSpend > NO_DISCOUNT_MAX:
    calcPrice = pSpend - pSpend / DISCOUNT_LEVEL
  else:
    calcPrice = pSpend

  return calcPrice

# -------------------------------------------------------------------
# Main program
# -------------------------------------------------------------------

# ======> Add code below

spend = float(input("Enter spend: "))

print("|{:^20}|".format("Final Price"))
print("-" * 22)

if spend <= 0:
  print("|{:^20}|".format("Invalid input"))
else:
  finalPrice = calculateFinalPrice(spend)
  print("|{:^20.2f}|".format(finalPrice))


