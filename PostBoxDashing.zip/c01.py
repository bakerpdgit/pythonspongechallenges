from random import randint
from time import sleep

# ============================================================
# Postbox Dash (Shortest Route Challenge)
# ------------------------------------------------------------
# You are the postman. Your van starts at V.
# There are postboxes labelled 0,1,2,... and you must type the
# order to visit them.
#
# Distance uses Manhattan (taxi) distance:
# distance = abs(x1-x2) + abs(y1-y2)
# ============================================================

# ==> Task 1 - Let the user choose the grid size (try 8 to 15)
SIZE = 10

# ==> Task 2 - Let the user choose how many postboxes (2 to 10)
POSTBOX_COUNT = 10

# ==> Task 3 - Improve the display (emojis, colours, better symbols, etc.)
SYMBOLS = {"empty": ".", "van": "V", "delivered": "x"}

# ==> Task 4 - Add a menu so the user can pick:
#     - step-by-step (press Enter)
#     - auto-play (sleep for a short delay)
STEP_BY_STEP = True
STEP_DELAY = 0.25

# ==> Task 5 - Give the player 3 attempts and keep their best score
ATTEMPTS = 1

# ==> EXTENSION - Hide the computer's best ORDER so players can't copy it
SHOW_ANSWER_ORDER = False

# --- Sub-Programs ---


def manhattan(a, b):
  ax, ay = a
  bx, by = b
  return abs(ax - bx) + abs(ay - by)


def make_blank_grid(size):
  return [[SYMBOLS["empty"] for _ in range(size)] for _ in range(size)]


def random_free_position(size, used):
  while True:
    x = randint(0, size - 1)
    y = randint(0, size - 1)
    if (x, y) not in used:
      used.add((x, y))
      return (x, y)


def setup_town(size, postbox_count):
  labels = [str(i) for i in range(postbox_count)]

  used = set()
  postboxes = {}

  for label in labels:
    postboxes[label] = random_free_position(size, used)

  van_pos = random_free_position(size, used)
  return postboxes, van_pos, labels


def build_grid(size, postboxes, van_pos, delivered):
  grid = make_blank_grid(size)

  for label, (x, y) in postboxes.items():
    if label in delivered:
      grid[y][x] = SYMBOLS["delivered"]
    else:
      grid[y][x] = label

  vx, vy = van_pos
  grid[vy][vx] = SYMBOLS["van"]
  return grid


def print_grid(grid):
  print("\n" * 40)
  for row in grid:
    print(" ".join(row))
  print()


def parse_route(text):
  # Turns "3 4 0 1 5" or "34015" into a list of digits
  digits = []
  for ch in text:
    if ch.isdigit():
      digits.append(ch)
  return digits


def check_route(route, labels):
  if len(route) != len(labels):
    return False, "You must enter exactly {} digits.".format(len(labels))

  if set(route) != set(labels):
    return False, "Your route must use each digit {} exactly once.".format("".join(labels))

  return True, ""


def route_distance(start, route, postboxes):
  total = 0
  pos = start

  for label in route:
    next_pos = postboxes[label]
    total += manhattan(pos, next_pos)
    pos = next_pos

  return total


def play_route(size, postboxes, van_start, route):
  delivered = set()
  pos = van_start
  total = 0

  grid = build_grid(size, postboxes, pos, delivered)
  print_grid(grid)
  print("Van starts at {}.".format(pos))
  print("Your delivery order is: {}\n".format("".join(route)))

  if STEP_BY_STEP:
    input("Press Enter to start...")
  else:
    sleep(STEP_DELAY)

  for label in route:
    next_pos = postboxes[label]
    leg = manhattan(pos, next_pos)

    total += leg
    pos = next_pos
    delivered.add(label)

    grid = build_grid(size, postboxes, pos, delivered)
    print_grid(grid)
    print("Delivered to postbox {} at {} (+{} steps). Total = {}".format(label, pos, leg, total))

    if STEP_BY_STEP:
      input("Press Enter for next delivery...")
    else:
      sleep(STEP_DELAY)

  return total


def best_possible_route(start, postboxes, labels):
  # Finds the TRUE best possible distance (and one best order) using a dictionary.
  # You don't need to understand this to play the game!
  # ==> EXTENSION - Try to explain (in comments) how this works.

  dp = {}       # dp[(visited_set, last_label)] = best distance so far
  parent = {}   # parent[state] = previous_state (so we can rebuild the order)

  # Start by visiting each possible first postbox
  for label in labels:
    visited = frozenset([label])
    dp[(visited, label)] = manhattan(start, postboxes[label])
    parent[(visited, label)] = None

  # Build up longer and longer routes
  for _ in range(len(labels) - 1):
    next_dp = {}
    next_parent = {}

    for (visited, last_label), dist_so_far in dp.items():
      for new_label in labels:
        if new_label not in visited:
          new_visited = visited.union([new_label])
          new_dist = dist_so_far + manhattan(postboxes[last_label], postboxes[new_label])
          state = (new_visited, new_label)

          if state not in next_dp or new_dist < next_dp[state]:
            next_dp[state] = new_dist
            next_parent[state] = (visited, last_label)

    dp = next_dp
    parent.update(next_parent)

  # Pick the best finishing state
  all_visited = frozenset(labels)
  best_state = None
  best_dist = None

  for state, dist in dp.items():
    visited, last_label = state
    if visited == all_visited:
      if best_dist is None or dist < best_dist:
        best_dist = dist
        best_state = state

  # Rebuild the best order
  order = []
  state = best_state
  while state is not None:
    visited, last_label = state
    order.append(last_label)
    state = parent[state]
  order.reverse()

  return best_dist, order


# --- Run Game ---

if SIZE * SIZE < POSTBOX_COUNT + 1:
  print("Grid is too small for that many postboxes!")
else:
  postboxes, van_start, labels = setup_town(SIZE, POSTBOX_COUNT)

  # Show the starting town
  grid = build_grid(SIZE, postboxes, van_start, set())
  print_grid(grid)
  print("Postbox Dash!")
  print("Postboxes to visit: " + "".join(labels))
  print("Type the order to visit them (example: 3401592687).")
  print("Manhattan distance means you move like a taxi in a city grid.\n")

  # Computer calculates the best possible route for this town
  best_dist, best_order = best_possible_route(van_start, postboxes, labels)

  best_user = None

  for attempt in range(1, ATTEMPTS + 1):
    print("\nAttempt {}/{}".format(attempt, ATTEMPTS))

    # ==> Task 6 - Improve input so it accepts things like:
    #     "3,4,0,1,5,9,2,6,8,7" AND also rejects repeats with a nicer message
    while True:
      route_text = input("Your route: ")
      route = parse_route(route_text)
      ok, message = check_route(route, labels)
      if ok:
        break
      print("Not accepted:", message)

    user_total = play_route(SIZE, postboxes, van_start, route)

    print("\nYour total distance = {}".format(user_total))
    print("Best possible distance = {}".format(best_dist))
    print("You were {} steps away from the best.".format(user_total - best_dist))

    if best_user is None or user_total < best_user:
      best_user = user_total

    # ==> Task 7 - Add a “congratulations” message if the user matches the best distance!

  print("\nBest distance you achieved = {}".format(best_user))

  # Show / hide the computer answer order
  if SHOW_ANSWER_ORDER:
    print("One best order is:", "".join(best_order))
  else:
    print("Computer's best order is hidden (set SHOW_ANSWER_ORDER = True to reveal).")

  # ==> EXTENSION - Print coordinates (x,y) for each postbox to help planning
  # ==> EXTENSION - Animate the van moving one square at a time (not just jumping)
  # ==> EXTENSION - Add walls (#) and then you MUST stop using Manhattan distance:
  #               compute real shortest paths around walls (hint: BFS on a grid!)
