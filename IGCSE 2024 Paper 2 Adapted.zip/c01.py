# -------------------------------------------------------
# Global variables
# -------------------------------------------------------

# ==> Complete the line to initialise myName to an empty string
myName = 

# ==> Add a line to create an integer variable called myAge and
# initialise myAge to 0


# -------------------------------------------------------
# Main program
# -------------------------------------------------------

myName = input ("Enter your name: ")
myAge = int (input ("Enter your age: "))

# ==> Complete the test to check if the age is less than 30
if (myAge  30):

    # ==> Add a line to display a message that says "Welcome"
    