# IGCSE CS 2022 REWRITTEN FOR EDEXCEL CS STYLE

# -------------------------------------------
# Constants
# -------------------------------------------

STORED_LETTER = "g"

# -------------------------------------------
# Global variables
# -------------------------------------------

letter = ""

# -------------------------------------------
# Main Program
# -------------------------------------------

# input the choice of letter from the user
letter = input("Input a letter ")

# Letter converted to lower case
letter = letter.lower()

# ==> AMEND THE CODE BELOW TO COMPLETE THE IF STATEMENT
if letter < STORED_LETTER:
    print("the letter " + letter + " comes before the stored letter " + STORED_LETTER)
elif letter > STORED_LETTER:
    print("the letter " + letter + " comes after the stored letter " + STORED_LETTER)
else:
    print("the letter " + letter + " is the same as the stored letter " + STORED_LETTER)