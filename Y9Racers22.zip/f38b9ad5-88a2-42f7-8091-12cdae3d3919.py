print("TS")
