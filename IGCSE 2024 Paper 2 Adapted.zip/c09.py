# -------------------------------------------------------
# Global variables
# -------------------------------------------------------
starNames = ["Alasia", "Beid", "Castor", "Denebola",
                "Electra", "Fafnir", "Gudja", "Haedus",
                "Izar", "Jishui", "Kang", "Lich", 
                "Maia", "Nahn", "Ogma", "Peacock"]

# -------------------------------------------------------
# Main program
# -------------------------------------------------------

# ==> Write your code here

for count in range(0, len(starNames), 2):
  print(starNames[count])
