print("CW")
