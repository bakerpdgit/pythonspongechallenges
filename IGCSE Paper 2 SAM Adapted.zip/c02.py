# IGCSE CS SAMPLE ASSESSMENT REWRITTEN FOR EDEXCEL CS STYLE

# ---------------------------------
# Global variables
# ---------------------------------

# =====> Add code here

# ---------------------------------
# Main program
# ---------------------------------

# =====> Implement the flowchart logic